import { createBrowserRouter } from "react-router";
import Home from "./pages/home";
import TestSetup from "./pages/test-setup";
import Upload from "./pages/upload";
import Dashboard from "./pages/dashboard";
import Report from "./pages/report";
import GwaPage from "./pages/gwa";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/setup",
    Component: TestSetup,
  },
  {
    path: "/upload",
    Component: Upload,
  },
  {
    path: "/dashboard",
    Component: Dashboard,
  },
  {
    path: "/report",
    Component: Report,
  },
  {
    path: "/gwa",
    Component: GwaPage,
  },
]);
