import { User, Building, BookOpen, Save, ArrowLeft, LogOut, Check, Palette } from "lucide-react";
import type { TeacherProfile } from "./App";
import type { Theme } from "./themes";

interface SettingsViewProps {
  profile: TeacherProfile;
  onUpdate: (patch: Partial<TeacherProfile>) => void;
  onBack: () => void;
  onLogout: () => void;
  themeId: string;
  onThemeChange: (id: string) => void;
  themes: Theme[];
}

export default function SettingsView({
  profile,
  onUpdate,
  onBack,
  onLogout,
  themeId,
  onThemeChange,
  themes,
}: SettingsViewProps) {
  return (
    <div style={{ maxWidth: "800px", margin: "0 auto", padding: "40px 24px" }}>
      <button
        onClick={onBack}
        style={{
          display: "flex",
          alignItems: "center",
          gap: "8px",
          background: "none",
          border: "none",
          color: "var(--color-text-secondary)",
          cursor: "pointer",
          fontSize: "14px",
          fontWeight: 500,
          marginBottom: "32px",
          padding: 0,
        }}
      >
        <ArrowLeft size={16} /> Back to Dashboard
      </button>

      <h1 style={{ fontFamily: "var(--font-display)", color: "var(--color-primary)", fontSize: "32px", marginBottom: "8px" }}>
        Settings & Profile
      </h1>
      <p style={{ color: "var(--color-text-secondary)", fontSize: "16px", marginBottom: "40px" }}>
        Manage your personal information and application appearance.
      </p>

      {/* ── Teacher Profile ──────────────────────────────────────────────── */}
      <div style={{
        backgroundColor: "var(--color-surface)",
        borderRadius: "var(--radius-card)",
        border: "1px solid var(--color-border)",
        padding: "32px",
        boxShadow: "var(--shadow-card)",
        marginBottom: "24px",
      }}>
        <h2 style={{ fontFamily: "var(--font-display)", fontSize: "22px", color: "var(--color-text-primary)", marginBottom: "24px" }}>
          Teacher Profile
        </h2>

        <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: "20px", maxWidth: "480px" }}>
          <div>
            <label style={{ display: "block", fontSize: "13px", fontWeight: 600, color: "var(--color-text-primary)", marginBottom: "7px" }}>
              Full Name
            </label>
            <div style={{ position: "relative" }}>
              <User size={16} style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", color: "var(--color-text-secondary)" }} />
              <input
                type="text"
                value={profile.name}
                onChange={(e) => onUpdate({ name: e.target.value })}
                style={{ width: "100%", padding: "10px 12px 10px 38px", borderRadius: "var(--radius-input)", border: "1px solid var(--color-border)", backgroundColor: "var(--color-bg)", color: "var(--color-text-primary)", fontSize: "15px", outline: "none", boxSizing: "border-box" }}
                onFocus={(e) => (e.target.style.borderColor = "var(--color-primary)")}
                onBlur={(e) => (e.target.style.borderColor = "var(--color-border)")}
              />
            </div>
          </div>

          <div>
            <label style={{ display: "block", fontSize: "13px", fontWeight: 600, color: "var(--color-text-primary)", marginBottom: "7px" }}>
              School / Institution
            </label>
            <div style={{ position: "relative" }}>
              <Building size={16} style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", color: "var(--color-text-secondary)" }} />
              <input
                type="text"
                value={profile.school}
                onChange={(e) => onUpdate({ school: e.target.value })}
                style={{ width: "100%", padding: "10px 12px 10px 38px", borderRadius: "var(--radius-input)", border: "1px solid var(--color-border)", backgroundColor: "var(--color-bg)", color: "var(--color-text-primary)", fontSize: "15px", outline: "none", boxSizing: "border-box" }}
                onFocus={(e) => (e.target.style.borderColor = "var(--color-primary)")}
                onBlur={(e) => (e.target.style.borderColor = "var(--color-border)")}
              />
            </div>
          </div>

          <div>
            <label style={{ display: "block", fontSize: "13px", fontWeight: 600, color: "var(--color-text-primary)", marginBottom: "7px" }}>
              Department
            </label>
            <div style={{ position: "relative" }}>
              <BookOpen size={16} style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", color: "var(--color-text-secondary)" }} />
              <input
                type="text"
                value={profile.department}
                onChange={(e) => onUpdate({ department: e.target.value })}
                style={{ width: "100%", padding: "10px 12px 10px 38px", borderRadius: "var(--radius-input)", border: "1px solid var(--color-border)", backgroundColor: "var(--color-bg)", color: "var(--color-text-primary)", fontSize: "15px", outline: "none", boxSizing: "border-box" }}
                onFocus={(e) => (e.target.style.borderColor = "var(--color-primary)")}
                onBlur={(e) => (e.target.style.borderColor = "var(--color-border)")}
              />
            </div>
          </div>
        </div>
      </div>

      {/* ── Theme Picker ─────────────────────────────────────────────────── */}
      <div style={{
        backgroundColor: "var(--color-surface)",
        borderRadius: "var(--radius-card)",
        border: "1px solid var(--color-border)",
        padding: "32px",
        boxShadow: "var(--shadow-card)",
        marginBottom: "24px",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "8px" }}>
          <Palette size={18} style={{ color: "var(--color-primary)" }} />
          <h2 style={{ fontFamily: "var(--font-display)", fontSize: "22px", color: "var(--color-text-primary)", margin: 0 }}>
            Appearance
          </h2>
        </div>
        <p style={{ color: "var(--color-text-secondary)", fontSize: "13px", marginBottom: "24px" }}>
          Choose a color theme for the entire application.
        </p>

        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))",
          gap: "12px",
        }}>
          {themes.map((theme) => {
            const isActive = theme.id === themeId;
            return (
              <button
                key={theme.id}
                onClick={() => onThemeChange(theme.id)}
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "flex-start",
                  gap: "0",
                  padding: "0",
                  border: isActive ? `2px solid ${theme.accentSwatch}` : "2px solid var(--color-border)",
                  borderRadius: "12px",
                  cursor: "pointer",
                  backgroundColor: "transparent",
                  overflow: "hidden",
                  transition: "border-color 0.18s, box-shadow 0.18s",
                  boxShadow: isActive ? `0 0 0 3px ${theme.accentSwatch}22` : "none",
                  textAlign: "left",
                }}
                onMouseOver={(e) => {
                  if (!isActive) e.currentTarget.style.borderColor = theme.accentSwatch;
                }}
                onMouseOut={(e) => {
                  if (!isActive) e.currentTarget.style.borderColor = "var(--color-border)";
                }}
              >
                {/* Color swatch strip */}
                <div style={{
                  width: "100%",
                  height: "56px",
                  backgroundColor: theme.swatch,
                  position: "relative",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "flex-end",
                  padding: "8px",
                  boxSizing: "border-box",
                  borderBottom: `1px solid ${theme.accentSwatch}33`,
                }}>
                  {/* Accent dot */}
                  <div style={{
                    width: "28px",
                    height: "28px",
                    borderRadius: "50%",
                    backgroundColor: theme.accentSwatch,
                    flexShrink: 0,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}>
                    {isActive && <Check size={14} color="white" strokeWidth={3} />}
                  </div>
                  {/* Mini surface card preview */}
                  <div style={{
                    position: "absolute",
                    left: "10px",
                    top: "10px",
                    width: "40px",
                    height: "28px",
                    borderRadius: "4px",
                    backgroundColor: theme.tokens["--color-surface"],
                    border: `1px solid ${theme.accentSwatch}33`,
                    opacity: 0.9,
                  }} />
                </div>

                {/* Label */}
                <div style={{ padding: "10px 12px", backgroundColor: "var(--color-surface)", width: "100%", boxSizing: "border-box" }}>
                  <p style={{ fontSize: "13px", fontWeight: 600, color: "var(--color-text-primary)", margin: 0, marginBottom: "2px" }}>
                    {theme.name}
                  </p>
                  <p style={{ fontSize: "11px", color: "var(--color-text-secondary)", margin: 0, lineHeight: 1.4 }}>
                    {theme.concept}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* ── Footer actions ────────────────────────────────────────────────── */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <button
          onClick={onLogout}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "8px",
            backgroundColor: "transparent",
            color: "var(--color-danger)",
            border: "1px solid var(--color-danger)",
            borderRadius: "var(--radius-button)",
            padding: "10px 24px",
            fontSize: "14px",
            fontWeight: 600,
            cursor: "pointer",
            transition: "all 0.2s",
          }}
          onMouseOver={(e) => (e.currentTarget.style.backgroundColor = "var(--color-danger-soft)")}
          onMouseOut={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          <LogOut size={16} />
          Sign Out
        </button>

        <button
          onClick={onBack}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "8px",
            backgroundColor: "var(--color-primary)",
            color: "white",
            border: "none",
            borderRadius: "var(--radius-button)",
            padding: "10px 24px",
            fontSize: "14px",
            fontWeight: 600,
            cursor: "pointer",
            boxShadow: "var(--shadow-elevated)",
            transition: "opacity 0.2s",
          }}
          onMouseOver={(e) => (e.currentTarget.style.opacity = "0.85")}
          onMouseOut={(e) => (e.currentTarget.style.opacity = "1")}
        >
          <Save size={16} />
          Save Changes
        </button>
      </div>
    </div>
  );
}
