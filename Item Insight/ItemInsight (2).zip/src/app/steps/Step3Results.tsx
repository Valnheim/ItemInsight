import { HealthBar } from "../components/health-bar";
import type { AppState } from "../App";

interface Props {
  state: AppState;
  onBack: () => void;
  onNext: () => void;
}

// ── Computation ────────────────────────────────────────────────────────────

function computeItem(correct: number, wrong: number, numStudents: number) {
  const total = correct + wrong;
  const p = numStudents > 0 ? correct / numStudents : 0;
  return { correct, wrong, total, p };
}

function difficultyMeta(p: number): { label: string; color: string; soft: string } {
  if (p > 0.80) return { label: "Very Easy",      color: "var(--color-warning)", soft: "var(--color-warning-soft)" };
  if (p > 0.60) return { label: "Easy",            color: "var(--color-success)", soft: "var(--color-success-soft)" };
  if (p > 0.40) return { label: "Average",         color: "var(--color-success)", soft: "var(--color-success-soft)" };
  if (p > 0.20) return { label: "Difficult",       color: "var(--color-warning)", soft: "var(--color-warning-soft)" };
  return            { label: "Very Difficult", color: "var(--color-danger)",  soft: "var(--color-danger-soft)"  };
}

function statusMeta(p: number): { label: string; color: string; soft: string } {
  if (p > 0.80) return { label: "Too Easy",        color: "var(--color-warning)", soft: "var(--color-warning-soft)" };
  if (p < 0.20) return { label: "Too Hard",        color: "var(--color-danger)",  soft: "var(--color-danger-soft)"  };
  if (p >= 0.30 && p <= 0.70) return { label: "Good",   color: "var(--color-success)", soft: "var(--color-success-soft)" };
  return { label: "Acceptable", color: "var(--color-warning)", soft: "var(--color-warning-soft)" };
}

function avg(nums: number[]) {
  return nums.length > 0 ? nums.reduce((a, b) => a + b, 0) / nums.length : 0;
}

function qualityLabel(avgP: number, flagged: number, total: number): { text: string; color: string } {
  const flagRate = total > 0 ? flagged / total : 0;
  if (avgP >= 0.30 && avgP <= 0.70 && flagRate <= 0.15)
    return { text: "Excellent",       color: "var(--color-success)" };
  if (flagRate <= 0.35)
    return { text: "Acceptable",      color: "var(--color-warning)" };
  return { text: "Needs Revision", color: "var(--color-danger)"  };
}

// ── Component ─────────────────────────────────────────────────────────────

export default function Step3Results({ state, onBack, onNext }: Props) {
  const { numStudents, itemRows, testName, section } = state;

  const computed = itemRows.map((row) =>
    computeItem(parseInt(row.correct) || 0, parseInt(row.wrong) || 0, numStudents)
  );

  const avgP = avg(computed.map((c) => c.p));
  const flaggedCount = computed.filter((c) => {
    const s = statusMeta(c.p);
    return s.label !== "Good" && s.label !== "Acceptable";
  }).length;
  const quality = qualityLabel(avgP, flaggedCount, computed.length);

  const goodCount  = computed.filter((c) => statusMeta(c.p).label === "Good").length;
  const easyCount  = computed.filter((c) => c.p > 0.80).length;
  const hardCount  = computed.filter((c) => c.p < 0.20).length;

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: "24px" }}>
        <h1 style={{ fontSize: "20px", fontWeight: 600, color: "var(--color-text-primary)", marginBottom: "4px" }}>
          Item Analysis Results
        </h1>
        <p style={{ fontSize: "14px", color: "var(--color-text-secondary)" }}>
          {testName || "Test"} · {section || "Class"} · {numStudents} students · {computed.length} items
        </p>
      </div>

      {/* Summary cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "16px", marginBottom: "28px" }}>
        {[
          {
            label: "AVG. DIFFICULTY (p)",
            value: avgP.toFixed(2),
            sub: avgP >= 0.30 && avgP <= 0.70 ? "Optimal range" : avgP > 0.70 ? "Items are easy" : "Items are hard",
            color: avgP >= 0.30 && avgP <= 0.70 ? "var(--color-success)" : "var(--color-warning)",
          },
          {
            label: "GOOD ITEMS",
            value: String(goodCount),
            sub: `p between 0.30 and 0.70`,
            color: "var(--color-success)",
          },
          {
            label: "FLAGGED ITEMS",
            value: String(flaggedCount),
            sub: `${easyCount} too easy · ${hardCount} too hard`,
            color: flaggedCount === 0 ? "var(--color-success)" : "var(--color-danger)",
          },
          {
            label: "TEST QUALITY",
            value: quality.text,
            sub: `${computed.length - flaggedCount} of ${computed.length} items OK`,
            color: quality.color,
            isText: true,
          },
        ].map((card) => (
          <div
            key={card.label}
            style={{
              backgroundColor: "var(--color-surface)",
              borderRadius: "var(--radius-card)",
              boxShadow: "var(--shadow-card)",
              padding: "20px",
            }}
          >
            <p style={{ fontSize: "11px", fontWeight: 600, color: "var(--color-text-secondary)", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "8px" }}>
              {card.label}
            </p>
            <div
              style={{
                fontFamily: card.isText ? "var(--font-body)" : "var(--font-display)",
                fontSize: card.isText ? "20px" : "40px",
                color: card.color,
                lineHeight: 1,
                marginBottom: "6px",
                fontWeight: card.isText ? 700 : undefined,
              }}
            >
              {card.value}
            </div>
            <p style={{ fontSize: "12px", color: "var(--color-text-secondary)" }}>{card.sub}</p>
          </div>
        ))}
      </div>

      {/* Results table */}
      <div
        style={{
          backgroundColor: "var(--color-surface)",
          borderRadius: "var(--radius-card)",
          boxShadow: "var(--shadow-card)",
          overflow: "hidden",
          marginBottom: "20px",
        }}
      >
        {/* Column headers */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "64px 80px 80px 88px 160px 110px 110px",
            padding: "10px 0",
            backgroundColor: "var(--color-surface-alt)",
            borderBottom: "1px solid var(--color-border)",
          }}
        >
          {[
            { label: "Item",       align: "left"   },
            { label: "✓ Correct",  align: "center", color: "var(--color-success)" },
            { label: "✗ Wrong",    align: "center", color: "var(--color-danger)"  },
            { label: "p",          align: "center" },
            { label: "Difficulty bar", align: "left" },
            { label: "Difficulty", align: "left"   },
            { label: "Status",     align: "left"   },
          ].map((h) => (
            <span
              key={h.label}
              style={{
                padding: "0 12px",
                fontSize: "11px",
                fontWeight: 700,
                color: (h as { color?: string }).color ?? "var(--color-text-secondary)",
                textTransform: "uppercase",
                letterSpacing: "0.06em",
                textAlign: h.align as React.CSSProperties["textAlign"],
              }}
            >
              {h.label}
            </span>
          ))}
        </div>

        {/* Rows */}
        <div style={{ maxHeight: "62vh", overflowY: "auto" }}>
          {computed.map((c, i) => {
            const diff = difficultyMeta(c.p);
            const stat = statusMeta(c.p);

            return (
              <div
                key={i}
                style={{
                  display: "grid",
                  gridTemplateColumns: "64px 80px 80px 88px 160px 110px 110px",
                  alignItems: "center",
                  borderBottom: i < computed.length - 1 ? "1px solid var(--color-border)" : "none",
                  backgroundColor: i % 2 === 0 ? "transparent" : "var(--color-surface-alt)",
                  padding: "10px 0",
                }}
              >
                {/* Item */}
                <span style={{ padding: "0 12px", fontFamily: "var(--font-data)", fontWeight: 600, fontSize: "13px", color: "var(--color-text-primary)" }}>
                  {String(i + 1).padStart(2, "0")}
                </span>

                {/* Correct */}
                <span style={{ padding: "0 12px", textAlign: "center", fontFamily: "var(--font-data)", fontWeight: 700, fontSize: "14px", color: "var(--color-success)" }}>
                  {c.correct}
                </span>

                {/* Wrong */}
                <span style={{ padding: "0 12px", textAlign: "center", fontFamily: "var(--font-data)", fontWeight: 700, fontSize: "14px", color: "var(--color-danger)" }}>
                  {c.wrong}
                </span>

                {/* p value */}
                <span style={{ padding: "0 12px", textAlign: "center", fontFamily: "var(--font-data)", fontWeight: 700, fontSize: "14px", color: "var(--color-text-primary)" }}>
                  {c.p.toFixed(2)}
                </span>

                {/* Health bar */}
                <div style={{ padding: "0 12px" }}>
                  <HealthBar value={c.p} size="small" />
                </div>

                {/* Difficulty badge */}
                <div style={{ padding: "0 8px" }}>
                  <Badge label={diff.label} color={diff.color} soft={diff.soft} />
                </div>

                {/* Status badge */}
                <div style={{ padding: "0 8px" }}>
                  <Badge label={stat.label} color={stat.color} soft={stat.soft} dot />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Legend */}
      <div
        style={{
          padding: "12px 16px",
          backgroundColor: "var(--color-surface)",
          borderRadius: "var(--radius-inner)",
          border: "1px solid var(--color-border)",
          fontSize: "12px",
          color: "var(--color-text-secondary)",
          marginBottom: "24px",
          lineHeight: 1.7,
        }}
      >
        <strong style={{ color: "var(--color-text-primary)" }}>p (difficulty index)</strong> = correct ÷ total students.&nbsp;
        Red zone: p &lt; 0.20 (too hard) or p &gt; 0.80 (too easy).&nbsp;
        Green zone: 0.20 ≤ p ≤ 0.80.&nbsp;
        Optimal range: 0.30 – 0.70.
      </div>

      {/* Footer actions */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <button onClick={onBack} style={backBtnStyle}>← Back</button>
        <div style={{ display: "flex", gap: "12px" }}>
          <button onClick={() => window.print()} style={secondaryBtnStyle}>Print Report</button>
          <button
            onClick={onNext}
            style={{
              padding: "10px 24px",
              backgroundColor: "var(--color-primary)",
              color: "white",
              border: "none",
              borderRadius: "var(--radius-button)",
              fontSize: "14px",
              fontWeight: 600,
              cursor: "pointer",
            }}
            onMouseEnter={(e) => { e.currentTarget.style.boxShadow = "var(--shadow-button-hover)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.boxShadow = "none"; }}
          >
            Continue to GWA →
          </button>
        </div>
      </div>
    </div>
  );
}

function Badge({ label, color, soft, dot }: { label: string; color: string; soft: string; dot?: boolean }) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: "4px",
        padding: "3px 9px",
        borderRadius: "var(--radius-pill)",
        backgroundColor: soft,
        color,
        fontSize: "11px",
        fontWeight: 600,
        whiteSpace: "nowrap",
      }}
    >
      {dot && <span style={{ width: "5px", height: "5px", borderRadius: "50%", backgroundColor: color, flexShrink: 0 }} />}
      {label}
    </span>
  );
}

const backBtnStyle: React.CSSProperties = {
  background: "none",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-button)",
  cursor: "pointer",
  fontSize: "13px",
  fontWeight: 500,
  color: "var(--color-text-secondary)",
  padding: "9px 16px",
};

const secondaryBtnStyle: React.CSSProperties = {
  padding: "10px 20px",
  backgroundColor: "transparent",
  color: "var(--color-primary)",
  border: "1px solid var(--color-primary)",
  borderRadius: "var(--radius-button)",
  fontSize: "14px",
  fontWeight: 500,
  cursor: "pointer",
};
