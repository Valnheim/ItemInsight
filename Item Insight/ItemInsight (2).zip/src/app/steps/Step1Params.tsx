import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import type { AppState } from "../App";

interface Props {
  state: AppState;
  update: (patch: Partial<AppState>) => void;
  onNext: () => void;
}

const CHOICES = ["A", "B", "C", "D", "E"];

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "10px 12px",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-input)",
  fontSize: "14px",
  color: "var(--color-text-primary)",
  backgroundColor: "var(--color-surface)",
  outline: "none",
  boxSizing: "border-box",
  fontFamily: "var(--font-body)",
};

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: "20px" }}>
      <label style={{ display: "block", fontSize: "11px", fontWeight: 700, color: "var(--color-text-secondary)", textTransform: "uppercase", letterSpacing: "0.07em", marginBottom: "6px" }}>
        {label}
      </label>
      {children}
    </div>
  );
}

export default function Step1Params({ state, update, onNext }: Props) {
  const [showKey, setShowKey] = useState(false);
  const valid = state.numQuestions >= 1 && state.numStudents >= 2;

  const numQ = state.numQuestions;

  // Sync answer key length whenever numQuestions changes
  const syncedKey = Array.from({ length: numQ }, (_, i) => state.answerKey[i] ?? "");

  const setKeyAnswer = (i: number, val: string) => {
    const next = [...syncedKey];
    next[i] = val;
    update({ answerKey: next });
  };

  const keyFilled = syncedKey.filter((k) => k !== "").length;
  const keyComplete = keyFilled === numQ;

  return (
    <div style={{ maxWidth: "520px", margin: "0 auto" }}>
      <div style={{ backgroundColor: "var(--color-surface)", borderRadius: "var(--radius-card)", boxShadow: "var(--shadow-card)", padding: "40px" }}>
        <h1 style={{ fontFamily: "var(--font-display)", fontSize: "26px", fontWeight: 700, color: "var(--color-text-primary)", marginBottom: "6px" }}>
          Test Parameters
        </h1>
        <p style={{ fontSize: "14px", color: "var(--color-text-secondary)", marginBottom: "32px", fontFamily: "var(--font-body)" }}>
          Set up the test. You will enter per-item counts in the next step.
        </p>

        <Field label="Test Name">
          <input type="text" placeholder="e.g. Q2 Science Exam" value={state.testName}
            onChange={(e) => update({ testName: e.target.value })} style={inputStyle}
            onFocus={(e) => { e.target.style.borderColor = "var(--color-primary)"; }}
            onBlur={(e)  => { e.target.style.borderColor = "var(--color-border)";  }} />
        </Field>

        <Field label="Section / Class">
          <input type="text" placeholder="e.g. Grade 10-A" value={state.section}
            onChange={(e) => update({ section: e.target.value })} style={inputStyle}
            onFocus={(e) => { e.target.style.borderColor = "var(--color-primary)"; }}
            onBlur={(e)  => { e.target.style.borderColor = "var(--color-border)";  }} />
        </Field>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginBottom: "20px" }}>
          <Field label="No. of Questions">
            <input type="number" min={1} max={100} value={state.numQuestions}
              onChange={(e) => {
                const n = Math.max(1, Math.min(100, parseInt(e.target.value) || 1));
                update({ numQuestions: n, answerKey: Array.from({ length: n }, (_, i) => state.answerKey[i] ?? "") });
              }}
              style={{ ...inputStyle, fontFamily: "var(--font-data)" }}
              onFocus={(e) => { e.target.style.borderColor = "var(--color-primary)"; }}
              onBlur={(e)  => { e.target.style.borderColor = "var(--color-border)";  }} />
          </Field>
          <Field label="No. of Students">
            <input type="number" min={2} max={500} value={state.numStudents}
              onChange={(e) => update({ numStudents: Math.max(2, Math.min(500, parseInt(e.target.value) || 2)) })}
              style={{ ...inputStyle, fontFamily: "var(--font-data)" }}
              onFocus={(e) => { e.target.style.borderColor = "var(--color-primary)"; }}
              onBlur={(e)  => { e.target.style.borderColor = "var(--color-border)";  }} />
          </Field>
        </div>

        {/* Answer Key — collapsible, required for camera scanning */}
        <div style={{ marginBottom: "28px" }}>
          <button
            onClick={() => setShowKey((v) => !v)}
            style={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "12px 16px",
              backgroundColor: showKey ? "var(--color-primary)" : "var(--color-surface-alt)",
              color: showKey ? "white" : "var(--color-text-primary)",
              border: `1px solid ${showKey ? "var(--color-primary)" : "var(--color-border)"}`,
              borderRadius: showKey ? "var(--radius-input) var(--radius-input) 0 0" : "var(--radius-input)",
              cursor: "pointer",
              fontSize: "13px",
              fontWeight: 600,
              fontFamily: "var(--font-body)",
              transition: "all 0.15s",
            }}
          >
            <span style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              Answer Key
              {keyFilled > 0 && (
                <span style={{
                  padding: "2px 8px",
                  borderRadius: "var(--radius-pill)",
                  backgroundColor: showKey ? "rgba(255,255,255,0.2)" : keyComplete ? "var(--color-success-soft)" : "var(--color-warning-soft)",
                  color: showKey ? "white" : keyComplete ? "var(--color-success)" : "var(--color-warning)",
                  fontSize: "11px",
                  fontFamily: "var(--font-data)",
                }}>
                  {keyFilled}/{numQ}
                </span>
              )}
              {keyFilled === 0 && (
                <span style={{ fontSize: "11px", opacity: 0.7, fontWeight: 400 }}>
                  — required for camera scanning
                </span>
              )}
            </span>
            {showKey ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </button>

          {showKey && (
            <div style={{
              border: "1px solid var(--color-primary)",
              borderTop: "none",
              borderRadius: "0 0 var(--radius-input) var(--radius-input)",
              backgroundColor: "var(--color-surface)",
              padding: "16px",
            }}>
              <p style={{ fontSize: "12px", color: "var(--color-text-secondary)", marginBottom: "12px", fontStyle: "italic" }}>
                Select the correct answer for each item. This is used to automatically mark scanned student sheets.
              </p>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: "8px" }}>
                {syncedKey.map((ans, i) => (
                  <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "4px" }}>
                    <span style={{ fontSize: "11px", fontFamily: "var(--font-data)", color: "var(--color-text-secondary)", fontWeight: 600 }}>
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <select
                      value={ans}
                      onChange={(e) => setKeyAnswer(i, e.target.value)}
                      style={{
                        width: "100%",
                        padding: "6px 4px",
                        border: `1px solid ${ans ? "var(--color-primary)" : "var(--color-border)"}`,
                        borderRadius: "var(--radius-input)",
                        fontSize: "14px",
                        fontFamily: "var(--font-data)",
                        fontWeight: 700,
                        color: ans ? "var(--color-primary)" : "var(--color-text-secondary)",
                        backgroundColor: ans ? "var(--color-primary-soft)" : "var(--color-surface-alt)",
                        cursor: "pointer",
                        textAlign: "center",
                        outline: "none",
                      }}
                    >
                      <option value="">—</option>
                      {CHOICES.map((c) => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                ))}
              </div>

              {keyComplete && (
                <div style={{ marginTop: "12px", padding: "8px 12px", backgroundColor: "var(--color-success-soft)", borderRadius: "var(--radius-inner)", fontSize: "12px", color: "var(--color-success)", fontWeight: 500 }}>
                  ✓ Answer key complete — camera scanning is ready
                </div>
              )}
            </div>
          )}
        </div>

        <button
          onClick={onNext}
          disabled={!valid}
          style={{
            width: "100%",
            padding: "13px",
            backgroundColor: valid ? "var(--color-primary)" : "var(--color-border)",
            color: valid ? "white" : "var(--color-text-secondary)",
            border: "none",
            borderRadius: "var(--radius-button)",
            fontSize: "14px",
            fontWeight: 600,
            cursor: valid ? "pointer" : "not-allowed",
            fontFamily: "var(--font-body)",
            transition: "all 0.15s",
          }}
          onMouseEnter={(e) => { if (valid) e.currentTarget.style.boxShadow = "var(--shadow-button-hover)"; }}
          onMouseLeave={(e) => { e.currentTarget.style.boxShadow = "none"; }}
        >
          Begin Analysis →
        </button>
      </div>
    </div>
  );
}
