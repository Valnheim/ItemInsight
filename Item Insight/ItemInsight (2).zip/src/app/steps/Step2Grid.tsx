import { useState } from "react";
import { Camera, ScanLine } from "lucide-react";
import CameraScanner from "../components/CameraScanner";
import type { AppState, ItemRow } from "../App";

interface Props {
  state: AppState;
  update: (patch: Partial<AppState>) => void;
  onBack: () => void;
  onNext: () => void;
}

export default function Step2Grid({ state, update, onBack, onNext }: Props) {
  const { numStudents, numQuestions, itemRows, answerKey, scansCount } = state;
  const [scannerOpen, setScannerOpen] = useState(false);

  const hasKey = answerKey.length === numQuestions && answerKey.some((k) => k !== "");

  // ── Manual entry handlers ──────────────────────────────────────────────

  const setCorrect = (i: number, val: string) => {
    const clean = val.replace(/[^0-9]/g, "");
    const num   = parseInt(clean);
    const correct = isNaN(num) ? "" : String(Math.min(num, numStudents));
    const wrong   = correct !== "" ? String(numStudents - parseInt(correct)) : "";
    const rows = itemRows.map((r, idx) => (idx === i ? { correct, wrong } : r));
    update({ itemRows: rows });
  };

  const setWrong = (i: number, val: string) => {
    const clean = val.replace(/[^0-9]/g, "");
    const num   = parseInt(clean);
    const wrong = isNaN(num) ? "" : String(Math.min(num, numStudents));
    const rows  = itemRows.map((r, idx) => (idx === i ? { ...r, wrong } : r));
    update({ itemRows: rows });
  };

  // ── Apply scanned answers → increment tallies ──────────────────────────

  const applyScannedAnswers = (scannedAnswers: string[]) => {
    const rows: ItemRow[] = itemRows.map((row, i) => {
      const correctKey = answerKey[i] ?? "";
      const stuAnswer  = scannedAnswers[i] ?? "";
      if (!stuAnswer || !correctKey) return row;

      const prevCorrect = row.correct !== "" ? parseInt(row.correct) : 0;
      const prevWrong   = row.wrong   !== "" ? parseInt(row.wrong)   : 0;

      if (stuAnswer === correctKey) {
        const newCorrect = prevCorrect + 1;
        const newWrong   = prevWrong;
        return {
          correct: String(newCorrect),
          wrong:   String(newWrong),
        };
      } else {
        const newCorrect = prevCorrect;
        const newWrong   = prevWrong + 1;
        return {
          correct: String(newCorrect),
          wrong:   String(newWrong),
        };
      }
    });
    update({ itemRows: rows, scansCount: scansCount + 1 });
  };

  const allFilled   = itemRows.length === numQuestions && itemRows.every((r) => r.correct !== "");
  const filledCount = itemRows.filter((r) => r.correct !== "").length;

  return (
    <div style={{ maxWidth: "600px", margin: "0 auto" }}>

      {/* Section header */}
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: "20px", gap: "16px" }}>
        <p style={{ fontSize: "12px", fontWeight: 700, color: "var(--color-primary)", letterSpacing: "0.08em", textTransform: "uppercase", paddingTop: "2px" }}>
          Right / Wrong Per Item — {numStudents} Students
          {scansCount > 0 && (
            <span style={{ marginLeft: "10px", fontWeight: 500, color: "var(--color-text-secondary)", textTransform: "none", letterSpacing: 0 }}>
              ({scansCount} sheet{scansCount !== 1 ? "s" : ""} scanned)
            </span>
          )}
        </p>

        {/* Scan button */}
        <button
          onClick={() => setScannerOpen(true)}
          title={!hasKey ? "Add an answer key in Step 1 to enable scanning" : "Scan a student answer sheet"}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "7px",
            padding: "8px 14px",
            backgroundColor: hasKey ? "var(--color-primary)" : "var(--color-surface-alt)",
            color: hasKey ? "white" : "var(--color-text-secondary)",
            border: `1px solid ${hasKey ? "var(--color-primary)" : "var(--color-border)"}`,
            borderRadius: "var(--radius-button)",
            cursor: hasKey ? "pointer" : "not-allowed",
            fontSize: "13px",
            fontWeight: 600,
            whiteSpace: "nowrap",
            flexShrink: 0,
            transition: "all 0.15s",
          }}
          onMouseEnter={(e) => { if (hasKey) e.currentTarget.style.boxShadow = "var(--shadow-button-hover)"; }}
          onMouseLeave={(e) => { e.currentTarget.style.boxShadow = "none"; }}
        >
          <Camera size={15} />
          Scan Sheet
          {!hasKey && (
            <span style={{ fontSize: "10px", opacity: 0.7, fontWeight: 400 }}>(needs key)</span>
          )}
        </button>
      </div>

      {/* Scan mode notice */}
      {scansCount > 0 && (
        <div style={{
          display: "flex",
          alignItems: "center",
          gap: "10px",
          padding: "10px 14px",
          backgroundColor: "var(--color-primary-soft)",
          border: "1px solid var(--color-primary)",
          borderRadius: "var(--radius-inner)",
          marginBottom: "16px",
          fontSize: "13px",
          color: "var(--color-primary)",
        }}>
          <ScanLine size={16} />
          <span>
            Tallies are auto-updated from scanned sheets. You can also edit the numbers manually below.
          </span>
        </div>
      )}

      {/* Table card */}
      <div style={{ backgroundColor: "var(--color-surface)", borderRadius: "var(--radius-card)", boxShadow: "var(--shadow-card)", overflow: "hidden" }}>

        {/* Column headers */}
        <div style={{ display: "grid", gridTemplateColumns: "120px 1fr 1fr 100px", padding: "12px 24px", borderBottom: "2px solid var(--color-border)", backgroundColor: "var(--color-surface)" }}>
          <span style={thStyle}>Item</span>
          <span style={{ ...thStyle, color: "var(--color-success)" }}>✓ Correct</span>
          <span style={{ ...thStyle, color: "var(--color-danger)" }}>✗ Wrong</span>
          <span style={{ ...thStyle, textAlign: "right" }}>Total</span>
        </div>

        {/* Rows */}
        <div style={{ maxHeight: "62vh", overflowY: "auto" }}>
          {itemRows.map((row, i) => {
            const correct = row.correct !== "" ? parseInt(row.correct) : null;
            const wrong   = row.wrong   !== "" ? parseInt(row.wrong)   : null;
            const total   = correct !== null && wrong !== null ? correct + wrong : null;
            const valid   = total !== null && total === numStudents;
            const hasData = correct !== null;

            return (
              <div
                key={i}
                style={{
                  display: "grid",
                  gridTemplateColumns: "120px 1fr 1fr 100px",
                  alignItems: "center",
                  padding: "10px 24px",
                  borderBottom: i < itemRows.length - 1 ? "1px solid var(--color-border)" : "none",
                  backgroundColor: i % 2 === 0 ? "transparent" : "#FAF7EE",
                }}
              >
                <span style={{ fontFamily: "var(--font-data)", fontSize: "14px", fontWeight: 500, color: "var(--color-text-primary)" }}>
                  Item {String(i + 1).padStart(2, "0")}
                </span>

                {/* Correct input */}
                <div>
                  <input
                    type="text"
                    inputMode="numeric"
                    value={row.correct}
                    placeholder=""
                    onChange={(e) => setCorrect(i, e.target.value)}
                    style={{
                      width: "68px",
                      height: "48px",
                      border: `2px solid ${hasData ? "var(--color-success)" : "var(--color-border)"}`,
                      borderRadius: "10px",
                      fontSize: "20px",
                      fontFamily: "var(--font-data)",
                      fontWeight: 700,
                      color: hasData ? "var(--color-success)" : "var(--color-text-secondary)",
                      backgroundColor: hasData ? "var(--color-success-soft)" : "var(--color-surface-alt)",
                      textAlign: "center",
                      outline: "none",
                      transition: "all 0.15s",
                    }}
                    onFocus={(e) => { e.target.style.borderColor = "var(--color-success)"; e.target.style.backgroundColor = "var(--color-success-soft)"; }}
                    onBlur={(e)  => { if (!row.correct) { e.target.style.borderColor = "var(--color-border)"; e.target.style.backgroundColor = "var(--color-surface-alt)"; } }}
                  />
                </div>

                {/* Wrong — auto-filled, editable */}
                <div>
                  <input
                    type="text"
                    inputMode="numeric"
                    value={row.wrong}
                    placeholder=""
                    onChange={(e) => setWrong(i, e.target.value)}
                    style={{
                      width: "68px",
                      height: "48px",
                      border: `2px solid ${wrong !== null ? "var(--color-danger)" : "var(--color-border)"}`,
                      borderRadius: "10px",
                      fontSize: "20px",
                      fontFamily: "var(--font-data)",
                      fontWeight: 700,
                      color: wrong !== null ? "var(--color-danger)" : "var(--color-text-secondary)",
                      backgroundColor: wrong !== null ? "var(--color-danger-soft)" : "var(--color-surface-alt)",
                      textAlign: "center",
                      outline: "none",
                      transition: "all 0.15s",
                    }}
                    onFocus={(e) => { e.target.style.borderColor = "var(--color-danger)"; e.target.style.backgroundColor = "var(--color-danger-soft)"; }}
                    onBlur={(e)  => { if (!row.wrong) { e.target.style.borderColor = "var(--color-border)"; e.target.style.backgroundColor = "var(--color-surface-alt)"; } }}
                  />
                </div>

                {/* Total */}
                <div style={{ textAlign: "right" }}>
                  {total !== null ? (
                    <span style={{ fontFamily: "var(--font-data)", fontSize: "14px", fontWeight: 600, color: valid ? "var(--color-success)" : "var(--color-danger)" }}>
                      {total} {valid ? "✓" : "✗"}
                    </span>
                  ) : (
                    <span style={{ fontFamily: "var(--font-data)", fontSize: "14px", color: "var(--color-border)" }}>—</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Card footer */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 24px", borderTop: "1px solid var(--color-border)", backgroundColor: "var(--color-surface-alt)" }}>
          <p style={{ fontSize: "12px", color: "var(--color-text-secondary)" }}>
            Correct count auto-fills wrong. Edit wrong manually if students skipped items.
          </p>
          <span style={{ fontFamily: "var(--font-data)", fontSize: "12px", color: "var(--color-primary)", fontWeight: 600, whiteSpace: "nowrap", marginLeft: "16px" }}>
            {filledCount} / {numQuestions}
          </span>
        </div>
      </div>

      {/* Navigation */}
      <div style={{ display: "flex", justifyContent: "space-between", marginTop: "24px", alignItems: "center" }}>
        <button onClick={onBack} style={backBtnStyle}>← Back</button>
        <button
          onClick={onNext}
          disabled={!allFilled}
          style={{
            padding: "10px 28px",
            backgroundColor: allFilled ? "var(--color-primary)" : "var(--color-border)",
            color: allFilled ? "white" : "var(--color-text-secondary)",
            border: "none",
            borderRadius: "var(--radius-button)",
            fontSize: "14px",
            fontWeight: 600,
            cursor: allFilled ? "pointer" : "not-allowed",
            transition: "all 0.15s",
          }}
          onMouseEnter={(e) => { if (allFilled) e.currentTarget.style.boxShadow = "var(--shadow-button-hover)"; }}
          onMouseLeave={(e) => { e.currentTarget.style.boxShadow = "none"; }}
        >
          Compute Analysis →
        </button>
      </div>

      {/* Camera scanner modal */}
      {scannerOpen && hasKey && (
        <CameraScanner
          numQuestions={numQuestions}
          answerKey={answerKey}
          onApply={applyScannedAnswers}
          onClose={() => setScannerOpen(false)}
        />
      )}
    </div>
  );
}

const thStyle: React.CSSProperties = {
  fontSize: "11px",
  fontWeight: 700,
  color: "var(--color-text-secondary)",
  textTransform: "uppercase",
  letterSpacing: "0.07em",
};

const backBtnStyle: React.CSSProperties = {
  background: "none",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-button)",
  cursor: "pointer",
  fontSize: "13px",
  fontWeight: 500,
  color: "var(--color-text-secondary)",
  padding: "9px 16px",
};
