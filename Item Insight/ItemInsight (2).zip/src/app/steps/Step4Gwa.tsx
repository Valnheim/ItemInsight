import { useState } from "react";
import { Plus, Trash2, Printer } from "lucide-react";
import type { AppState, StudentRecord } from "../App";

interface Props {
  state: AppState;
  update: (patch: Partial<AppState>) => void;
  onBack: () => void;
  onFinish?: () => void;
}

// ── PH Grade Scale ────────────────────────────────────────────────────────

const PH_SCALE = [
  { min: 99, max: 100, grade: 1.00, remark: "Excellent"    },
  { min: 96, max: 98,  grade: 1.25, remark: "Excellent"    },
  { min: 93, max: 95,  grade: 1.50, remark: "Very Good"    },
  { min: 90, max: 92,  grade: 1.75, remark: "Very Good"    },
  { min: 87, max: 89,  grade: 2.00, remark: "Good"         },
  { min: 84, max: 86,  grade: 2.25, remark: "Good"         },
  { min: 81, max: 83,  grade: 2.50, remark: "Satisfactory" },
  { min: 78, max: 80,  grade: 2.75, remark: "Satisfactory" },
  { min: 75, max: 77,  grade: 3.00, remark: "Passing"      },
  { min: 0,  max: 74,  grade: 5.00, remark: "Failed"       },
];

function toPhGrade(pct: number): { grade: number; remark: string } {
  return PH_SCALE.find((s) => pct >= s.min && pct <= s.max) ?? { grade: 5.00, remark: "Failed" };
}

function computeGwa(grades: number[]): number {
  if (grades.length === 0) return 5.00;
  return Math.round((grades.reduce((a, b) => a + b, 0) / grades.length) * 100) / 100;
}

function gwaColor(gwa: number): string {
  if (gwa <= 1.75) return "var(--color-success)";
  if (gwa <= 2.75) return "var(--color-warning)";
  if (gwa <= 3.00) return "var(--color-text-primary)";
  return "var(--color-danger)";
}
function gwaSoft(gwa: number): string {
  if (gwa <= 1.75) return "var(--color-success-soft)";
  if (gwa <= 2.75) return "var(--color-warning-soft)";
  if (gwa <= 3.00) return "var(--color-primary-soft)";
  return "var(--color-danger-soft)";
}
function gwaRemark(gwa: number): string {
  if (gwa <= 1.50) return "Excellent";
  if (gwa <= 2.00) return "Very Good";
  if (gwa <= 2.50) return "Good";
  if (gwa <= 3.00) return "Passing";
  return "Failed";
}

// ── Component ─────────────────────────────────────────────────────────────

export default function Step4Gwa({ state, update, onBack, onFinish }: Props) {
  const { subjects, students, testName, section } = state;
  const [newSubject, setNewSubject] = useState("");
  const [showScale, setShowScale] = useState(false);

  // ── Subject management ──

  const addSubject = () => {
    const s = newSubject.trim();
    if (!s || subjects.includes(s)) return;
    update({
      subjects: [...subjects, s],
      students: students.map((st) => ({ ...st, percentages: [...st.percentages, ""] })),
    });
    setNewSubject("");
  };

  const removeSubject = (idx: number) => {
    update({
      subjects: subjects.filter((_, i) => i !== idx),
      students: students.map((st) => ({
        ...st,
        percentages: st.percentages.filter((_, i) => i !== idx),
      })),
    });
  };

  // ── Student management ──

  const addStudent = () => {
    const next = students.length + 1;
    update({
      students: [
        ...students,
        { name: `Student ${String(next).padStart(2, "0")}`, percentages: subjects.map(() => "") },
      ],
    });
  };

  const removeStudent = (idx: number) => {
    update({ students: students.filter((_, i) => i !== idx) });
  };

  const updateName = (idx: number, name: string) => {
    update({
      students: students.map((s, i) => (i === idx ? { ...s, name } : s)),
    });
  };

  const updatePct = (si: number, subIdx: number, val: string) => {
    const clean = val.replace(/[^0-9]/g, "");
    const num = parseInt(clean);
    const clamped = isNaN(num) ? "" : String(Math.min(100, num));
    update({
      students: students.map((s, i) => {
        if (i !== si) return s;
        const p = [...s.percentages];
        p[subIdx] = clamped;
        return { ...s, percentages: p };
      }),
    });
  };

  // ── Per-student computed data ──

  const rows = students.map((st) => {
    const entries = st.percentages.map((p, si) => {
      if (p === "") return null;
      const pct = parseInt(p);
      const ph = toPhGrade(pct);
      return { pct, grade: ph.grade, remark: ph.remark };
    });
    const validGrades = entries.filter(Boolean).map((e) => e!.grade);
    const gwa = validGrades.length > 0 ? computeGwa(validGrades) : null;
    return { ...st, entries, gwa };
  });

  // ── Class summary ──

  const completedRows = rows.filter((r) => r.gwa !== null);
  const classGwa =
    completedRows.length > 0
      ? computeGwa(completedRows.map((r) => r.gwa!))
      : null;
  const passCount = completedRows.filter((r) => r.gwa! <= 3.00).length;
  const failCount = completedRows.filter((r) => r.gwa! > 3.00).length;
  const honorsCount = completedRows.filter((r) => r.gwa! <= 1.50).length;

  return (
    <div>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: "24px" }}>
        <div>
          <h1 style={{ fontSize: "20px", fontWeight: 600, color: "var(--color-text-primary)", marginBottom: "4px" }}>
            GWA & Export
          </h1>
          <p style={{ fontSize: "14px", color: "var(--color-text-secondary)" }}>
            {testName || "Test"} · {section || "Class"} · Philippine 1.00–5.00 scale
          </p>
        </div>
        <button
          onClick={() => window.print()}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "6px",
            padding: "9px 18px",
            backgroundColor: "var(--color-primary)",
            color: "white",
            border: "none",
            borderRadius: "var(--radius-button)",
            fontSize: "13px",
            fontWeight: 600,
            cursor: "pointer",
          }}
          onMouseEnter={(e) => { e.currentTarget.style.boxShadow = "var(--shadow-button-hover)"; }}
          onMouseLeave={(e) => { e.currentTarget.style.boxShadow = "none"; }}
        >
          <Printer size={14} />
          Print / Export
        </button>
      </div>

      {/* Class summary cards */}
      {completedRows.length > 0 && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "16px", marginBottom: "24px" }}>
          {[
            {
              label: "Class GWA",
              value: classGwa?.toFixed(2) ?? "—",
              sub: classGwa ? gwaRemark(classGwa) : "",
              color: classGwa ? gwaColor(classGwa) : "var(--color-text-secondary)",
              large: true,
            },
            {
              label: "Passed",
              value: String(passCount),
              sub: `${completedRows.length > 0 ? Math.round((passCount / completedRows.length) * 100) : 0}% of class`,
              color: "var(--color-success)",
            },
            {
              label: "Failed",
              value: String(failCount),
              sub: failCount === 0 ? "None failed" : "GWA > 3.00",
              color: failCount > 0 ? "var(--color-danger)" : "var(--color-text-secondary)",
            },
            {
              label: "With Honors",
              value: String(honorsCount),
              sub: "GWA ≤ 1.50",
              color: "var(--color-primary)",
            },
          ].map((card) => (
            <div
              key={card.label}
              style={{
                backgroundColor: "var(--color-surface)",
                borderRadius: "var(--radius-card)",
                boxShadow: "var(--shadow-card)",
                padding: "18px 20px",
              }}
            >
              <p style={{ fontSize: "11px", fontWeight: 600, color: "var(--color-text-secondary)", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "6px" }}>
                {card.label}
              </p>
              <div
                style={{
                  fontFamily: "var(--font-display)",
                  fontSize: card.large ? "40px" : "32px",
                  color: card.color,
                  lineHeight: 1,
                  marginBottom: "4px",
                }}
              >
                {card.value}
              </div>
              <p style={{ fontSize: "12px", color: "var(--color-text-secondary)" }}>{card.sub}</p>
            </div>
          ))}
        </div>
      )}

      {/* Two-column layout: main table + grade scale */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 220px", gap: "20px", alignItems: "start" }}>

        {/* Left: student GWA table */}
        <div>
          {/* Subject management row */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              marginBottom: "12px",
              flexWrap: "wrap",
            }}
          >
            <span style={{ fontSize: "12px", fontWeight: 600, color: "var(--color-text-secondary)", textTransform: "uppercase", letterSpacing: "0.05em", marginRight: "4px" }}>
              Subjects:
            </span>
            {subjects.map((s, i) => (
              <span
                key={s}
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "4px",
                  padding: "3px 8px",
                  backgroundColor: "var(--color-primary-soft)",
                  color: "var(--color-primary)",
                  borderRadius: "var(--radius-pill)",
                  fontSize: "12px",
                  fontWeight: 500,
                }}
              >
                {s}
                <button
                  onClick={() => removeSubject(i)}
                  style={{ background: "none", border: "none", cursor: "pointer", color: "inherit", padding: 0, fontSize: "14px", lineHeight: 1, display: "flex", alignItems: "center" }}
                >
                  ×
                </button>
              </span>
            ))}
            <div style={{ display: "flex", gap: "4px" }}>
              <input
                type="text"
                placeholder="Add subject…"
                value={newSubject}
                onChange={(e) => setNewSubject(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") addSubject(); }}
                style={{
                  padding: "4px 8px",
                  border: "1px solid var(--color-border)",
                  borderRadius: "var(--radius-inner)",
                  fontSize: "12px",
                  outline: "none",
                  width: "120px",
                  backgroundColor: "var(--color-surface)",
                }}
                onFocus={(e) => { e.target.style.borderColor = "var(--color-primary)"; }}
                onBlur={(e) => { e.target.style.borderColor = "var(--color-border)"; }}
              />
              <button
                onClick={addSubject}
                style={{
                  padding: "4px 8px",
                  backgroundColor: "var(--color-primary)",
                  color: "white",
                  border: "none",
                  borderRadius: "var(--radius-inner)",
                  cursor: "pointer",
                  fontSize: "12px",
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <Plus size={12} />
              </button>
            </div>
          </div>

          {/* Student table */}
          <div
            style={{
              backgroundColor: "var(--color-surface)",
              borderRadius: "var(--radius-card)",
              boxShadow: "var(--shadow-card)",
              overflow: "hidden",
            }}
          >
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "13px" }}>
                <thead>
                  <tr
                    style={{
                      backgroundColor: "var(--color-surface-alt)",
                      borderBottom: "1px solid var(--color-border)",
                    }}
                  >
                    <th style={{ ...thStyle, padding: "10px 12px", textAlign: "left", position: "sticky", left: 0, backgroundColor: "var(--color-surface-alt)", zIndex: 2, minWidth: "140px" }}>
                      Student
                    </th>
                    {subjects.map((s) => (
                      <th key={s} style={{ ...thStyle, padding: "10px 8px", textAlign: "center", minWidth: "88px" }}>
                        {s}
                      </th>
                    ))}
                    <th style={{ ...thStyle, padding: "10px 10px", textAlign: "center", minWidth: "72px" }}>GWA</th>
                    <th style={{ ...thStyle, padding: "10px 10px", textAlign: "left",   minWidth: "90px"  }}>Status</th>
                    <th style={{ padding: "10px 8px", width: "36px" }} />
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, si) => {
                    const isAt = row.gwa !== null && row.gwa > 3.00;
                    return (
                      <tr
                        key={si}
                        style={{
                          borderBottom: si < rows.length - 1 ? "1px solid var(--color-border)" : "none",
                          backgroundColor: isAt ? "var(--color-danger-soft)" : si % 2 === 0 ? "transparent" : "var(--color-surface-alt)",
                        }}
                      >
                        {/* Name */}
                        <td
                          style={{
                            padding: "8px 12px",
                            position: "sticky",
                            left: 0,
                            backgroundColor: isAt ? "var(--color-danger-soft)" : si % 2 === 0 ? "var(--color-surface)" : "var(--color-surface-alt)",
                            zIndex: 1,
                          }}
                        >
                          <input
                            type="text"
                            value={row.name}
                            onChange={(e) => updateName(si, e.target.value)}
                            style={{
                              width: "100%",
                              border: "none",
                              background: "transparent",
                              fontSize: "13px",
                              fontWeight: 500,
                              color: "var(--color-text-primary)",
                              outline: "none",
                            }}
                          />
                        </td>

                        {/* Subject grade cells */}
                        {subjects.map((_, subIdx) => {
                          const entry = row.entries[subIdx];
                          return (
                            <td key={subIdx} style={{ padding: "6px 6px", textAlign: "center" }}>
                              <div>
                                <input
                                  type="text"
                                  inputMode="numeric"
                                  placeholder="0–100"
                                  value={row.percentages[subIdx] ?? ""}
                                  onChange={(e) => updatePct(si, subIdx, e.target.value)}
                                  style={{
                                    width: "56px",
                                    padding: "5px 6px",
                                    border: `1px solid ${entry ? (entry.grade <= 3.00 ? "var(--color-success)" : "var(--color-danger)") : "var(--color-border)"}`,
                                    borderRadius: "var(--radius-inner)",
                                    fontSize: "12px",
                                    fontFamily: "var(--font-data)",
                                    fontWeight: 600,
                                    color: entry ? (entry.grade <= 3.00 ? "var(--color-success)" : "var(--color-danger)") : "var(--color-text-secondary)",
                                    backgroundColor: entry ? (entry.grade <= 3.00 ? "var(--color-success-soft)" : "var(--color-danger-soft)") : "var(--color-surface)",
                                    textAlign: "center",
                                    outline: "none",
                                    display: "block",
                                    margin: "0 auto",
                                  }}
                                  onFocus={(e) => { e.target.style.borderColor = "var(--color-primary)"; }}
                                  onBlur={(e) => {
                                    if (!entry) e.target.style.borderColor = "var(--color-border)";
                                    else e.target.style.borderColor = entry.grade <= 3.00 ? "var(--color-success)" : "var(--color-danger)";
                                  }}
                                />
                                {entry && (
                                  <span
                                    style={{
                                      display: "block",
                                      fontSize: "10px",
                                      fontFamily: "var(--font-data)",
                                      fontWeight: 700,
                                      color: entry.grade <= 3.00 ? "var(--color-success)" : "var(--color-danger)",
                                      marginTop: "2px",
                                    }}
                                  >
                                    {entry.grade.toFixed(2)}
                                  </span>
                                )}
                              </div>
                            </td>
                          );
                        })}

                        {/* GWA */}
                        <td style={{ padding: "8px 10px", textAlign: "center" }}>
                          {row.gwa !== null ? (
                            <span
                              style={{
                                display: "inline-block",
                                padding: "3px 8px",
                                borderRadius: "var(--radius-pill)",
                                backgroundColor: gwaSoft(row.gwa),
                                color: gwaColor(row.gwa),
                                fontFamily: "var(--font-data)",
                                fontWeight: 700,
                                fontSize: "12px",
                              }}
                            >
                              {row.gwa.toFixed(2)}
                            </span>
                          ) : (
                            <span style={{ color: "var(--color-border)", fontSize: "12px" }}>—</span>
                          )}
                        </td>

                        {/* Status */}
                        <td style={{ padding: "8px 10px", fontSize: "12px", fontWeight: 500 }}>
                          {row.gwa !== null && (
                            <span style={{ color: gwaColor(row.gwa) }}>{gwaRemark(row.gwa)}</span>
                          )}
                        </td>

                        {/* Remove */}
                        <td style={{ padding: "8px", textAlign: "center" }}>
                          <button
                            onClick={() => removeStudent(si)}
                            style={{
                              background: "none",
                              border: "none",
                              cursor: "pointer",
                              color: "var(--color-text-secondary)",
                              padding: "3px",
                              display: "flex",
                              alignItems: "center",
                            }}
                            onMouseEnter={(e) => { e.currentTarget.style.color = "var(--color-danger)"; }}
                            onMouseLeave={(e) => { e.currentTarget.style.color = "var(--color-text-secondary)"; }}
                          >
                            <Trash2 size={13} />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Add student row */}
            <div style={{ padding: "12px 16px", borderTop: "1px solid var(--color-border)" }}>
              <button
                onClick={addStudent}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "6px",
                  background: "none",
                  border: "1px dashed var(--color-border)",
                  borderRadius: "var(--radius-button)",
                  cursor: "pointer",
                  fontSize: "13px",
                  fontWeight: 500,
                  color: "var(--color-text-secondary)",
                  padding: "7px 14px",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = "var(--color-primary)";
                  e.currentTarget.style.color = "var(--color-primary)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = "var(--color-border)";
                  e.currentTarget.style.color = "var(--color-text-secondary)";
                }}
              >
                <Plus size={14} />
                Add Student
              </button>
            </div>
          </div>
        </div>

        {/* Right: PH Grade Scale reference */}
        <div style={{ position: "sticky", top: "76px" }}>
          {/* Toggle button */}
          <button
            onClick={() => setShowScale((v) => !v)}
            style={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "10px 14px",
              backgroundColor: "var(--color-surface)",
              border: "1px solid var(--color-border)",
              borderRadius: showScale ? "var(--radius-inner) var(--radius-inner) 0 0" : "var(--radius-inner)",
              cursor: "pointer",
              fontSize: "12px",
              fontWeight: 600,
              color: "var(--color-text-secondary)",
              textTransform: "uppercase",
              letterSpacing: "0.05em",
            }}
          >
            PH Grading Scale
            <span style={{ fontSize: "16px", lineHeight: 1 }}>{showScale ? "−" : "+"}</span>
          </button>

          {showScale && (
            <div
              style={{
                backgroundColor: "var(--color-surface)",
                border: "1px solid var(--color-border)",
                borderTop: "none",
                borderRadius: "0 0 var(--radius-inner) var(--radius-inner)",
                overflow: "hidden",
              }}
            >
              <table style={{ width: "100%", fontSize: "11px", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ backgroundColor: "var(--color-surface-alt)" }}>
                    <th style={{ ...thStyle, padding: "7px 10px", textAlign: "center" }}>Grade</th>
                    <th style={{ ...thStyle, padding: "7px 10px", textAlign: "center" }}>Range</th>
                    <th style={{ ...thStyle, padding: "7px 10px", textAlign: "left" }}>Remark</th>
                  </tr>
                </thead>
                <tbody>
                  {PH_SCALE.map((row, i) => (
                    <tr key={row.grade} style={{ borderTop: i > 0 ? "1px solid var(--color-border)" : "none" }}>
                      <td style={{ padding: "6px 10px", textAlign: "center", fontFamily: "var(--font-data)", fontWeight: 700, color: row.grade <= 3.00 ? "var(--color-success)" : "var(--color-danger)", fontSize: "12px" }}>
                        {row.grade.toFixed(2)}
                      </td>
                      <td style={{ padding: "6px 10px", textAlign: "center", fontFamily: "var(--font-data)", color: "var(--color-text-secondary)", fontSize: "11px" }}>
                        {row.max === 100 ? `${row.min}–100%` : row.min === 0 ? `< ${row.max + 1}%` : `${row.min}–${row.max}%`}
                      </td>
                      <td style={{ padding: "6px 10px", color: row.grade <= 3.00 ? "var(--color-success)" : "var(--color-danger)", fontWeight: 500 }}>
                        {row.remark}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div style={{ marginTop: "24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <button onClick={onBack} style={backBtnStyle}>← Back to Results</button>
        {onFinish && (
          <button onClick={onFinish} style={{
            background: "var(--color-primary)",
            border: "none",
            borderRadius: "var(--radius-button)",
            cursor: "pointer",
            fontSize: "14px",
            fontWeight: 600,
            color: "white",
            padding: "10px 24px",
            boxShadow: "var(--shadow-card)",
          }}>
            Save & Return to Dashboard
          </button>
        )}
      </div>
    </div>
  );
}

const thStyle: React.CSSProperties = {
  fontSize: "11px",
  fontWeight: 600,
  color: "var(--color-text-secondary)",
  textTransform: "uppercase",
  letterSpacing: "0.05em",
};

const backBtnStyle: React.CSSProperties = {
  background: "none",
  border: "1px solid var(--color-border)",
  borderRadius: "var(--radius-button)",
  cursor: "pointer",
  fontSize: "13px",
  fontWeight: 500,
  color: "var(--color-text-secondary)",
  padding: "9px 16px",
};
