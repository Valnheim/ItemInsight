import { Plus, FileText, Settings as SettingsIcon, MoreVertical, Calendar, Inbox, BarChart2 } from "lucide-react";
import { type TestRecord } from "./App";

interface DashboardProps {
  pastTests: TestRecord[];
  onNewTest: () => void;
  onOpenSettings: () => void;
}

export default function Dashboard({ pastTests, onNewTest, onOpenSettings }: DashboardProps) {
  return (
    <div style={{ maxWidth: "1040px", margin: "0 auto", padding: "40px 24px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: "40px" }}>
        <div>
          <h1 style={{ fontFamily: "var(--font-display)", color: "var(--color-primary)", fontSize: "36px", marginBottom: "8px" }}>
            Teacher Dashboard
          </h1>
          <p style={{ color: "var(--color-text-secondary)", fontSize: "16px" }}>
            Welcome back. Manage your tests, analyze results, and compute GWAs.
          </p>
        </div>
        <button
          onClick={onNewTest}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "8px",
            backgroundColor: "var(--color-primary)",
            color: "white",
            border: "none",
            borderRadius: "var(--radius-button)",
            padding: "12px 24px",
            fontSize: "15px",
            fontWeight: 500,
            cursor: "pointer",
            boxShadow: "var(--shadow-elevated)",
            transition: "all 0.2s",
          }}
          onMouseOver={(e) => (e.currentTarget.style.backgroundColor = "var(--color-success)")}
          onMouseOut={(e) => (e.currentTarget.style.backgroundColor = "var(--color-primary)")}
        >
          <Plus size={18} />
          Upload New Test Data
        </button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "24px" }}>
        {/* Main List */}
        <div style={{
          backgroundColor: "var(--color-surface)",
          borderRadius: "var(--radius-card)",
          border: "1px solid var(--color-border)",
          padding: "24px",
          boxShadow: "var(--shadow-card)",
        }}>
          <h2 style={{ fontFamily: "var(--font-display)", color: "var(--color-text-primary)", fontSize: "24px", marginBottom: "20px" }}>
            My Tests / Exams
          </h2>
          
          <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
            {pastTests.length === 0 ? (
              <div style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                padding: "48px 24px",
                backgroundColor: "var(--color-surface-alt)",
                borderRadius: "var(--radius-card)",
                border: "1px dashed var(--color-border)",
                textAlign: "center",
                color: "var(--color-text-secondary)"
              }}>
                <Inbox size={48} style={{ color: "var(--color-border)", marginBottom: "16px" }} />
                <h3 style={{ fontSize: "16px", fontWeight: 600, color: "var(--color-text-primary)", marginBottom: "8px" }}>No tests recorded yet</h3>
                <p style={{ fontSize: "14px", maxWidth: "250px", marginBottom: "20px" }}>
                  Upload new test data or use the camera scanner to record your first set of test results.
                </p>
                <button
                  onClick={onNewTest}
                  style={{
                    backgroundColor: "white",
                    border: "1px solid var(--color-border)",
                    color: "var(--color-primary)",
                    padding: "8px 16px",
                    borderRadius: "var(--radius-button)",
                    fontSize: "14px",
                    fontWeight: 500,
                    cursor: "pointer",
                    boxShadow: "var(--shadow-card)",
                  }}
                >
                  Upload Test Data
                </button>
              </div>
            ) : (
              pastTests.map((test) => (
                <div
                  key={test.id}
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "16px",
                    backgroundColor: "var(--color-surface-alt)",
                    borderRadius: "var(--radius-card)",
                    border: "1px solid var(--color-border)",
                  }}
                >
                  <div style={{ display: "flex", gap: "16px", alignItems: "center" }}>
                    <div style={{
                      width: "48px",
                      height: "48px",
                      borderRadius: "8px",
                      backgroundColor: "var(--color-primary-soft)",
                      color: "var(--color-primary)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}>
                      <FileText size={24} />
                    </div>
                    <div>
                      <h3 style={{ fontSize: "16px", fontWeight: 600, color: "var(--color-text-primary)", marginBottom: "4px" }}>
                        {test.testName || "Untitled Test"} {test.section ? `- ${test.section}` : ""}
                      </h3>
                      <div style={{ display: "flex", gap: "16px", color: "var(--color-text-secondary)", fontSize: "13px" }}>
                        <span style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                          <Calendar size={14} /> {test.date}
                        </span>
                        <span>{test.numStudents} Students</span>
                        <span>{test.numQuestions} Items</span>
                      </div>
                    </div>
                  </div>
                  
                  <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontSize: "12px", color: "var(--color-text-secondary)", textTransform: "uppercase", letterSpacing: "0.5px" }}>Avg Score</div>
                      <div style={{ fontFamily: "var(--font-data)", fontSize: "18px", color: "var(--color-primary)", fontWeight: 600 }}>{test.avgScore}</div>
                    </div>
                    <button style={{
                      background: "none",
                      border: "none",
                      color: "var(--color-text-secondary)",
                      cursor: "pointer",
                      padding: "4px",
                    }}>
                      <MoreVertical size={20} />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Sidebar Actions */}
        <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
          <div style={{
            backgroundColor: "var(--color-surface)",
            borderRadius: "var(--radius-card)",
            border: "1px solid var(--color-border)",
            padding: "24px",
            boxShadow: "var(--shadow-card)",
          }}>
            <h3 style={{ fontFamily: "var(--font-display)", color: "var(--color-text-primary)", fontSize: "20px", marginBottom: "16px" }}>
              Quick Actions
            </h3>
            <button
              disabled={pastTests.length === 0}
              style={{
                width: "100%",
                display: "flex",
                alignItems: "center",
                gap: "12px",
                padding: "12px 16px",
                backgroundColor: "transparent",
                border: "1px solid var(--color-border)",
                borderRadius: "var(--radius-button)",
                color: pastTests.length === 0 ? "var(--color-text-secondary)" : "var(--color-text-primary)",
                opacity: pastTests.length === 0 ? 0.5 : 1,
                cursor: pastTests.length === 0 ? "not-allowed" : "pointer",
                marginBottom: "12px",
                textAlign: "left",
                transition: "background 0.2s",
              }}
              onMouseOver={(e) => {
                if (pastTests.length > 0) e.currentTarget.style.backgroundColor = "var(--color-surface-alt)";
              }}
              onMouseOut={(e) => {
                if (pastTests.length > 0) e.currentTarget.style.backgroundColor = "transparent";
              }}
            >
              <BarChart2 size={18} color={pastTests.length === 0 ? "var(--color-text-secondary)" : "var(--color-primary)"} />
              <span style={{ fontWeight: 500 }}>View Past Reports</span>
            </button>
            <button
              onClick={onOpenSettings}
              style={{
                width: "100%",
                display: "flex",
                alignItems: "center",
                gap: "12px",
                padding: "12px 16px",
                backgroundColor: "transparent",
                border: "1px solid var(--color-border)",
                borderRadius: "var(--radius-button)",
                color: "var(--color-text-primary)",
                cursor: "pointer",
                textAlign: "left",
                transition: "background 0.2s",
              }}
              onMouseOver={(e) => (e.currentTarget.style.backgroundColor = "var(--color-surface-alt)")}
              onMouseOut={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
            >
              <SettingsIcon size={18} color="var(--color-primary)" />
              <span style={{ fontWeight: 500 }}>Settings / Profile</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
