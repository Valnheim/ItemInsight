import { useState } from "react";
import { Settings, LayoutGrid, BarChart2, GraduationCap } from "lucide-react";
import { AppLogo } from "./components/app-logo";
import Dashboard from "./Dashboard";
import LoginView from "./LoginView";
import SettingsView from "./SettingsView";
import Step1Params from "./steps/Step1Params";
import Step2Grid from "./steps/Step2Grid";
import Step3Results from "./steps/Step3Results";
import Step4Gwa from "./steps/Step4Gwa";
import { THEMES, THEME_STORAGE_KEY, getThemeById } from "./themes";

export type ItemRow = { correct: string; wrong: string };
export type StudentRecord = { name: string; percentages: string[] };

export interface AppState {
  testName: string;
  section: string;
  numQuestions: number;
  numStudents: number;
  answerKey: string[];
  itemRows: ItemRow[];
  scansCount: number;
  subjects: string[];
  students: StudentRecord[];
}

export interface TestRecord extends AppState {
  id: string;
  date: string;
  avgScore: string;
}

export interface TeacherProfile {
  name: string;
  school: string;
  department: string;
}

const INITIAL_TEST_STATE: AppState = {
  testName: "",
  section: "",
  numQuestions: 10,
  numStudents: 30,
  answerKey: [],
  itemRows: [],
  scansCount: 0,
  subjects: ["Science", "Math", "English", "Filipino", "TLE"],
  students: [],
};

const STEPS = [
  { n: 1 as const, label: "Test Parameters",    Icon: Settings      },
  { n: 2 as const, label: "Right / Wrong Grid", Icon: LayoutGrid    },
  { n: 3 as const, label: "Item Analysis",      Icon: BarChart2     },
  { n: 4 as const, label: "GWA & Export",       Icon: GraduationCap },
];

export default function App() {
  const [view, setView] = useState<"auth" | "dashboard" | "wizard" | "settings">("auth");
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [state, setState] = useState<AppState>(INITIAL_TEST_STATE);
  const [pastTests, setPastTests] = useState<TestRecord[]>([]);
  const [teacherProfile, setTeacherProfile] = useState<TeacherProfile>({
    name: "Juan Dela Cruz",
    school: "Manila Science High School",
    department: "Science Department",
  });
  const [themeId, setThemeId] = useState<string>(
    () => localStorage.getItem(THEME_STORAGE_KEY) ?? "academic"
  );

  const theme = getThemeById(themeId);
  const themeStyle = theme.tokens as React.CSSProperties;

  const handleThemeChange = (id: string) => {
    setThemeId(id);
    localStorage.setItem(THEME_STORAGE_KEY, id);
  };

  const update = (patch: Partial<AppState>) =>
    setState((s) => ({ ...s, ...patch }));

  const goTo = (next: 1 | 2 | 3 | 4) => {
    if (next === 2) {
      const rows: ItemRow[] = Array.from({ length: state.numQuestions }, (_, i) =>
        state.itemRows[i] ?? { correct: "", wrong: "" }
      );
      update({ itemRows: rows });
    }
    if (next === 4 && state.students.length === 0) {
      update({
        students: Array.from({ length: 5 }, (_, i) => ({
          name: `Student ${String(i + 1).padStart(2, "0")}`,
          percentages: state.subjects.map(() => ""),
        })),
      });
    }
    setStep(next);
  };

  const finishWizard = () => {
    let totalCorrects = 0;
    const totalItems = state.itemRows.length;
    state.itemRows.forEach((row) => {
      totalCorrects += parseInt(row.correct) || 0;
    });
    const possibleCorrects = totalItems * state.numStudents;
    const avg = possibleCorrects > 0 ? Math.round((totalCorrects / possibleCorrects) * 100) : 0;

    const newTest: TestRecord = {
      ...state,
      id: Math.random().toString(36).substr(2, 9),
      date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
      avgScore: `${avg}%`,
    };

    setPastTests((prev) => [newTest, ...prev]);
    setView("dashboard");
  };

  const startNewTest = () => {
    setState(INITIAL_TEST_STATE);
    setStep(1);
    setView("wizard");
  };

  const handleLogin = (email: string, isGuest?: boolean) => {
    if (isGuest) {
      setTeacherProfile({ name: "Guest Teacher", school: "—", department: "—" });
    } else {
      setTeacherProfile((prev) => ({ ...prev, name: email.split("@")[0] }));
    }
    setView("dashboard");
  };

  if (view === "auth") {
    return (
      <div style={themeStyle}>
        <LoginView onLogin={handleLogin} />
      </div>
    );
  }

  return (
    <div style={{ ...themeStyle, minHeight: "100vh", backgroundColor: "var(--color-bg)", fontFamily: "var(--font-body)" }}>
      {/* Sticky header */}
      <header style={{
        backgroundColor: "var(--color-surface)",
        borderBottom: "1px solid var(--color-border)",
        padding: "0 32px",
        position: "sticky",
        top: 0,
        zIndex: 50,
      }}>
        <div style={{
          maxWidth: "1040px",
          margin: "0 auto",
          height: "56px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}>
          <div
            onClick={() => setView("dashboard")}
            style={{ cursor: "pointer", transition: "opacity 0.2s" }}
            onMouseOver={(e) => (e.currentTarget.style.opacity = "0.7")}
            onMouseOut={(e) => (e.currentTarget.style.opacity = "1")}
          >
            <AppLogo size="small" />
          </div>

          {view === "wizard" && (
            <div style={{ display: "flex", alignItems: "center", gap: "2px" }}>
              {STEPS.map(({ n, label, Icon }, idx) => {
                const isActive = n === step;
                const isDone = n < step;
                const isLocked = n > step;
                return (
                  <div key={n} style={{ display: "flex", alignItems: "center" }}>
                    <button
                      onClick={() => { if (!isLocked) goTo(n); }}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "6px",
                        padding: "6px 12px",
                        border: "none",
                        borderRadius: "var(--radius-button)",
                        cursor: isLocked ? "default" : "pointer",
                        backgroundColor: isActive ? "var(--color-primary)" : isDone ? "var(--color-primary-soft)" : "transparent",
                        color: isActive ? "white" : isDone ? "var(--color-primary)" : "var(--color-text-secondary)",
                        fontSize: "13px",
                        fontWeight: isActive ? 600 : 400,
                        transition: "all 0.15s",
                        whiteSpace: "nowrap",
                      }}
                    >
                      <Icon size={14} />
                      <span>{label}</span>
                    </button>
                    {idx < STEPS.length - 1 && (
                      <div style={{ width: "20px", height: "1px", backgroundColor: "var(--color-border)", flexShrink: 0, margin: "0 2px" }} />
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </header>

      {view === "dashboard" && (
        <Dashboard
          pastTests={pastTests}
          onNewTest={startNewTest}
          onOpenSettings={() => setView("settings")}
        />
      )}

      {view === "settings" && (
        <SettingsView
          profile={teacherProfile}
          onUpdate={(patch) => setTeacherProfile((p) => ({ ...p, ...patch }))}
          onBack={() => setView("dashboard")}
          onLogout={() => setView("auth")}
          themeId={themeId}
          onThemeChange={handleThemeChange}
          themes={THEMES}
        />
      )}

      {view === "wizard" && (
        <main style={{ maxWidth: "1040px", margin: "0 auto", padding: "40px 24px" }}>
          {step === 1 && <Step1Params state={state} update={update} onNext={() => goTo(2)} />}
          {step === 2 && <Step2Grid state={state} update={update} onBack={() => goTo(1)} onNext={() => goTo(3)} />}
          {step === 3 && <Step3Results state={state} onBack={() => goTo(2)} onNext={() => goTo(4)} />}
          {step === 4 && <Step4Gwa state={state} update={update} onBack={() => goTo(3)} onFinish={finishWizard} />}
        </main>
      )}
    </div>
  );
}
