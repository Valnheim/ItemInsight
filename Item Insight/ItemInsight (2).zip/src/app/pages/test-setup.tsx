import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft } from 'lucide-react';

export default function TestSetup() {
  const navigate = useNavigate();
  const [answerKey, setAnswerKey] = useState<string[]>(new Array(20).fill(''));
  const [numItems, setNumItems] = useState(20);
  const [choicesPerItem, setChoicesPerItem] = useState(4);

  const handleAnswerChange = (index: number, value: string) => {
    const newAnswerKey = [...answerKey];
    newAnswerKey[index] = value.toUpperCase();
    setAnswerKey(newAnswerKey);
  };

  return (
    <div
      className="min-h-screen p-6 flex items-center justify-center"
      style={{
        backgroundColor: 'var(--color-bg)',
        fontFamily: 'var(--font-body)',
      }}
    >
      <div className="w-full max-w-[560px]">
        {/* Card */}
        <div
          style={{
            backgroundColor: 'var(--color-surface)',
            borderRadius: 'var(--radius-card)',
            boxShadow: 'var(--shadow-card)',
            padding: '32px',
          }}
        >
          {/* Header */}
          <div className="mb-8">
            <button
              onClick={() => navigate('/')}
              className="flex items-center gap-2 mb-4 transition-colors"
              style={{
                color: 'var(--color-primary)',
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                fontSize: '14px',
                padding: 0,
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = 'var(--color-text-primary)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = 'var(--color-primary)';
              }}
            >
              <ArrowLeft size={16} />
              Back
            </button>

            <h1
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: '20px',
                fontWeight: 600,
                color: 'var(--color-text-primary)',
                marginBottom: '8px',
              }}
            >
              Test Setup
            </h1>
          </div>

          {/* Answer Key Section */}
          <div className="mb-8">
            <h2
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: '15px',
                fontWeight: 600,
                color: 'var(--color-text-primary)',
                marginBottom: '4px',
              }}
            >
              Answer Key
            </h2>
            <p
              style={{
                fontSize: '12px',
                color: 'var(--color-text-secondary)',
                marginBottom: '16px',
              }}
            >
              Enter the correct answer for each item.
            </p>

            {/* Answer key grid */}
            <div className="grid grid-cols-5 gap-3">
              {answerKey.slice(0, 20).map((answer, index) => (
                <div key={index} className="flex flex-col gap-1">
                  <label
                    style={{
                      fontSize: '12px',
                      color: 'var(--color-text-secondary)',
                      textAlign: 'center',
                      fontFamily: 'var(--font-data)',
                    }}
                  >
                    {String(index + 1).padStart(2, '0')}
                  </label>
                  <input
                    type="text"
                    maxLength={1}
                    value={answer}
                    onChange={(e) => handleAnswerChange(index, e.target.value)}
                    className="text-center uppercase transition-all"
                    style={{
                      padding: '8px',
                      border: answer
                        ? '1px solid var(--color-primary)'
                        : '1px solid var(--color-border)',
                      borderRadius: 'var(--radius-input)',
                      fontSize: '14px',
                      fontWeight: 500,
                      backgroundColor: answer
                        ? 'var(--color-primary-soft)'
                        : 'var(--color-surface)',
                      color: 'var(--color-text-primary)',
                      borderLeft: answer
                        ? '3px solid var(--color-primary)'
                        : '1px solid var(--color-border)',
                      outline: 'none',
                    }}
                    onFocus={(e) => {
                      if (!answer) {
                        e.target.style.borderColor = 'var(--color-primary)';
                        e.target.style.backgroundColor = 'var(--color-primary-soft)';
                      }
                    }}
                    onBlur={(e) => {
                      if (!answer) {
                        e.target.style.borderColor = 'var(--color-border)';
                        e.target.style.backgroundColor = 'var(--color-surface)';
                      }
                    }}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Test Settings */}
          <div className="mb-8">
            <h2
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: '15px',
                fontWeight: 600,
                color: 'var(--color-text-primary)',
                marginBottom: '16px',
              }}
            >
              Test Settings
            </h2>

            <div className="flex gap-4">
              <div className="flex-1">
                <label
                  style={{
                    display: 'block',
                    fontSize: '12px',
                    fontWeight: 500,
                    color: 'var(--color-text-secondary)',
                    marginBottom: '4px',
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                  }}
                >
                  Number of Items
                </label>
                <input
                  type="number"
                  value={numItems}
                  onChange={(e) => setNumItems(Number(e.target.value))}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    border: '1px solid var(--color-border)',
                    borderRadius: 'var(--radius-input)',
                    fontSize: '14px',
                    color: 'var(--color-text-primary)',
                    fontFamily: 'var(--font-data)',
                  }}
                />
              </div>

              <div className="flex-1">
                <label
                  style={{
                    display: 'block',
                    fontSize: '12px',
                    fontWeight: 500,
                    color: 'var(--color-text-secondary)',
                    marginBottom: '4px',
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                  }}
                >
                  Choices Per Item
                </label>
                <select
                  value={choicesPerItem}
                  onChange={(e) => setChoicesPerItem(Number(e.target.value))}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    border: '1px solid var(--color-border)',
                    borderRadius: 'var(--radius-input)',
                    fontSize: '14px',
                    color: 'var(--color-text-primary)',
                    backgroundColor: 'var(--color-surface)',
                    cursor: 'pointer',
                  }}
                >
                  <option value={3}>3</option>
                  <option value={4}>4</option>
                  <option value={5}>5</option>
                </select>
              </div>
            </div>
          </div>

          {/* Continue Button */}
          <button
            onClick={() => navigate('/upload')}
            className="w-full transition-all"
            style={{
              backgroundColor: 'var(--color-primary)',
              color: 'white',
              padding: '12px',
              borderRadius: 'var(--radius-button)',
              border: 'none',
              fontSize: '14px',
              fontWeight: 500,
              cursor: 'pointer',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.boxShadow = 'var(--shadow-button-hover)';
              e.currentTarget.style.transform = 'translateY(-1px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.boxShadow = 'none';
              e.currentTarget.style.transform = 'translateY(0)';
            }}
          >
            Continue to Upload
          </button>
        </div>
      </div>
    </div>
  );
}
