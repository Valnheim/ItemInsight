import { useNavigate } from 'react-router';
import { Upload, Edit3, Lock } from 'lucide-react';
import { AppLogo } from '../components/app-logo';

export default function Home() {
  const navigate = useNavigate();

  return (
    <div
      className="min-h-screen flex items-center justify-center p-6"
      style={{
        backgroundColor: 'var(--color-bg)',
        backgroundImage: `radial-gradient(circle, var(--color-border) 1px, transparent 1px)`,
        backgroundSize: '24px 24px',
        fontFamily: 'var(--font-body)',
      }}
    >
      <div className="w-full max-w-[640px]">
        {/* Main card */}
        <div
          className="p-12 text-center"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderRadius: 'var(--radius-card)',
            boxShadow: 'var(--shadow-elevated)',
          }}
        >
          {/* Logo */}
          <div className="flex justify-center mb-6">
            <AppLogo size="large" />
          </div>

          {/* Tagline */}
          <h1
            className="mb-4"
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: '28px',
              fontWeight: 400,
              color: 'var(--color-text-primary)',
              lineHeight: 1.3,
            }}
          >
            See what your test is really measuring.
          </h1>

          {/* Description */}
          <p
            className="mb-8"
            style={{
              fontFamily: 'var(--font-body)',
              fontSize: '14px',
              color: 'var(--color-text-secondary)',
              lineHeight: 1.6,
              maxWidth: '480px',
              margin: '0 auto 32px',
            }}
          >
            Upload your class results and get an instant breakdown of each test item — difficulty, discrimination, and distractor quality.
          </p>

          {/* Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 justify-center mb-6">
            <button
              onClick={() => navigate('/setup')}
              className="group flex items-center justify-center gap-2 px-6 py-3 transition-all"
              style={{
                backgroundColor: 'var(--color-primary)',
                color: 'white',
                fontFamily: 'var(--font-body)',
                fontSize: '14px',
                fontWeight: 500,
                borderRadius: 'var(--radius-button)',
                border: 'none',
                cursor: 'pointer',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.boxShadow = 'var(--shadow-button-hover)';
                e.currentTarget.style.transform = 'translateY(-1px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.boxShadow = 'none';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              <Upload size={16} />
              Upload Answer Sheet
            </button>

            <button
              onClick={() => navigate('/setup')}
              className="group flex items-center justify-center gap-2 px-6 py-3 transition-all"
              style={{
                backgroundColor: 'transparent',
                color: 'var(--color-primary)',
                fontFamily: 'var(--font-body)',
                fontSize: '14px',
                fontWeight: 500,
                borderRadius: 'var(--radius-button)',
                border: '2px solid var(--color-primary)',
                cursor: 'pointer',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--color-primary-soft)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
              }}
            >
              <Edit3 size={16} />
              Enter Answers Manually
            </button>
          </div>

          {/* Hint */}
          <div
            className="flex items-center justify-center gap-2 pt-4"
            style={{
              color: 'var(--color-text-secondary)',
              fontSize: '12px',
              borderTop: '1px solid var(--color-border)',
            }}
          >
            <Lock size={14} />
            <span>No account needed. Works entirely in your browser.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
