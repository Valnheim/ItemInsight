import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, GraduationCap, Users, TrendingUp, Award } from 'lucide-react';
import { AppLogo } from '../components/app-logo';

// Philippine grading scale conversion
const GRADE_SCALE: { min: number; max: number; grade: number; remark: string }[] = [
  { min: 99, max: 100, grade: 1.00, remark: 'Excellent' },
  { min: 96, max: 98,  grade: 1.25, remark: 'Excellent' },
  { min: 93, max: 95,  grade: 1.50, remark: 'Very Good' },
  { min: 90, max: 92,  grade: 1.75, remark: 'Very Good' },
  { min: 87, max: 89,  grade: 2.00, remark: 'Good' },
  { min: 84, max: 86,  grade: 2.25, remark: 'Good' },
  { min: 81, max: 83,  grade: 2.50, remark: 'Satisfactory' },
  { min: 78, max: 80,  grade: 2.75, remark: 'Satisfactory' },
  { min: 75, max: 77,  grade: 3.00, remark: 'Passing' },
  { min: 0,  max: 74,  grade: 5.00, remark: 'Failed' },
];

function toPhilippineGrade(percentage: number): { grade: number; remark: string } {
  const entry = GRADE_SCALE.find((s) => percentage >= s.min && percentage <= s.max);
  return entry ?? { grade: 5.00, remark: 'Failed' };
}

function computeGwa(grades: number[]): number {
  if (grades.length === 0) return 5.00;
  const sum = grades.reduce((a, b) => a + b, 0);
  return Math.round((sum / grades.length) * 100) / 100;
}

function gwaToRemark(gwa: number): string {
  if (gwa <= 1.0) return 'Excellent';
  if (gwa <= 1.5) return 'Excellent';
  if (gwa <= 2.0) return 'Very Good';
  if (gwa <= 2.5) return 'Good';
  if (gwa <= 3.0) return 'Satisfactory';
  return 'Failed';
}

function gwaColor(gwa: number): string {
  if (gwa <= 1.75) return 'var(--color-success)';
  if (gwa <= 2.5)  return 'var(--color-warning)';
  if (gwa <= 3.0)  return 'var(--color-text-primary)';
  return 'var(--color-danger)';
}

function gwaColorSoft(gwa: number): string {
  if (gwa <= 1.75) return 'var(--color-success-soft)';
  if (gwa <= 2.5)  return 'var(--color-warning-soft)';
  if (gwa <= 3.0)  return 'var(--color-primary-soft)';
  return 'var(--color-danger-soft)';
}

const SUBJECTS = ['Science', 'Math', 'English', 'Filipino', 'TLE'];

// Each student: raw scores out of 20 per subject
const RAW_STUDENTS = [
  { name: 'Alcantara, Maria', scores: [18, 17, 19, 16, 18] },
  { name: 'Bautista, Juan', scores: [14, 12, 15, 13, 11] },
  { name: 'Cruz, Ana', scores: [20, 19, 20, 18, 19] },
  { name: 'De Leon, Pedro', scores: [10, 11, 9,  12, 10] },
  { name: 'Estrada, Rosa', scores: [16, 15, 17, 14, 16] },
  { name: 'Fernandez, Jose', scores: [13, 14, 12, 11, 13] },
  { name: 'Garcia, Elena', scores: [17, 18, 16, 19, 17] },
  { name: 'Hernandez, Miguel', scores: [8,  9,  10, 7,  8]  },
  { name: 'Ignacio, Luisa', scores: [19, 18, 20, 17, 19] },
  { name: 'Jimenez, Carlos', scores: [15, 16, 14, 15, 14] },
  { name: 'Lim, Patricia', scores: [12, 11, 13, 10, 12] },
  { name: 'Mendoza, Roberto', scores: [18, 17, 18, 16, 17] },
];

const ITEMS_TOTAL = 20;

const students = RAW_STUDENTS.map((s) => {
  const percentages = s.scores.map((sc) => Math.round((sc / ITEMS_TOTAL) * 100));
  const converted = percentages.map((p) => toPhilippineGrade(p));
  const gwa = computeGwa(converted.map((c) => c.grade));
  return {
    name: s.name,
    scores: s.scores,
    percentages,
    converted,
    gwa,
    remark: gwaToRemark(gwa),
    passed: gwa <= 3.00,
  };
});

const classGwa = computeGwa(students.map((s) => s.gwa));
const passCount = students.filter((s) => s.passed).length;
const failCount = students.length - passCount;
const highHonorsCount = students.filter((s) => s.gwa <= 1.50).length;

export default function GwaPage() {
  const navigate = useNavigate();
  const [activeNav, setActiveNav] = useState('gwa');
  const [selectedStudent, setSelectedStudent] = useState<number | null>(null);

  const navItems = [
    { id: 'overview', label: 'Overview', onClick: () => navigate('/dashboard') },
    { id: 'items', label: 'Item Results', onClick: () => navigate('/dashboard') },
    { id: 'gwa', label: 'GWA Analysis', onClick: () => setActiveNav('gwa') },
    { id: 'report', label: 'Report', onClick: () => navigate('/report') },
  ];

  const sel = selectedStudent !== null ? students[selectedStudent] : null;

  return (
    <div
      className="min-h-screen flex"
      style={{ backgroundColor: 'var(--color-bg)', fontFamily: 'var(--font-body)' }}
    >
      {/* Sidebar */}
      <div
        className="flex-shrink-0"
        style={{
          width: '240px',
          backgroundColor: 'var(--color-surface-alt)',
          borderRight: '1px solid var(--color-border)',
          padding: '24px',
        }}
      >
        <div className="mb-8">
          <AppLogo size="small" />
        </div>

        <div className="mb-8">
          <p
            className="mb-2"
            style={{
              fontSize: '12px',
              fontWeight: 500,
              color: 'var(--color-text-secondary)',
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
            }}
          >
            ANALYSIS
          </p>
          <nav className="space-y-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={item.onClick}
                className="w-full flex items-center gap-2 px-3 py-2 transition-all"
                style={{
                  backgroundColor: activeNav === item.id ? 'var(--color-primary-soft)' : 'transparent',
                  color: activeNav === item.id ? 'var(--color-primary)' : 'var(--color-text-secondary)',
                  borderRadius: 'var(--radius-inner)',
                  border: 'none',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: 500,
                  textAlign: 'left',
                }}
                onMouseEnter={(e) => {
                  if (activeNav !== item.id) e.currentTarget.style.backgroundColor = 'var(--color-surface)';
                }}
                onMouseLeave={(e) => {
                  if (activeNav !== item.id) e.currentTarget.style.backgroundColor = 'transparent';
                }}
              >
                {item.id === 'gwa' && <GraduationCap size={16} />}
                {item.id !== 'gwa' && <span style={{ width: 16, display: 'inline-block' }} />}
                {item.label}
              </button>
            ))}
          </nav>
        </div>

        <div
          style={{
            backgroundColor: 'var(--color-surface)',
            border: '1px solid var(--color-border)',
            borderRadius: 'var(--radius-inner)',
            padding: '12px',
          }}
        >
          <p className="mb-1" style={{ fontSize: '13px', fontWeight: 600, color: 'var(--color-text-primary)' }}>
            Q2 Science Exam
          </p>
          <div
            className="flex items-center gap-2 mb-1"
            style={{ fontSize: '12px', color: 'var(--color-text-secondary)' }}
          >
            <span>Items: <span style={{ fontFamily: 'var(--font-data)' }}>20</span></span>
            <span>|</span>
            <span>Students: <span style={{ fontFamily: 'var(--font-data)' }}>{students.length}</span></span>
          </div>
          <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>Grade 10-A · AY 2025–2026</p>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-y-auto">
        {/* Back bar */}
        <div
          className="flex items-center gap-3 px-8 py-4"
          style={{ borderBottom: '1px solid var(--color-border)', backgroundColor: 'var(--color-surface)' }}
        >
          <button
            onClick={() => navigate('/dashboard')}
            className="flex items-center gap-2 transition-colors"
            style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '14px', color: 'var(--color-primary)', fontWeight: 500, padding: 0 }}
            onMouseEnter={(e) => { e.currentTarget.style.color = 'var(--color-text-primary)'; }}
            onMouseLeave={(e) => { e.currentTarget.style.color = 'var(--color-primary)'; }}
          >
            <ArrowLeft size={15} />
            Back to Dashboard
          </button>
          <span style={{ color: 'var(--color-border)', fontSize: '16px' }}>/</span>
          <span style={{ fontSize: '14px', color: 'var(--color-text-secondary)' }}>GWA Analysis</span>
        </div>

        <div className="p-8">
          {/* Header */}
          <div className="mb-6">
            <h1 style={{ fontFamily: 'var(--font-body)', fontSize: '20px', fontWeight: 600, color: 'var(--color-text-primary)', marginBottom: '4px' }}>
              General Weighted Average (GWA)
            </h1>
            <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)' }}>
              Philippine grading scale (1.00–5.00) · Grade 10-A · {students.length} students · {SUBJECTS.length} subjects
            </p>
          </div>

          {/* Summary cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <SummaryCard
              label="Class GWA"
              value={classGwa.toFixed(2)}
              sub={gwaToRemark(classGwa)}
              valueColor={gwaColor(classGwa)}
              large
            />
            <SummaryCard
              label="Passed"
              value={String(passCount)}
              sub={`${Math.round((passCount / students.length) * 100)}% of class`}
              valueColor="var(--color-success)"
            />
            <SummaryCard
              label="Failed"
              value={String(failCount)}
              sub={failCount === 0 ? 'None failed' : 'Below 3.00 GWA'}
              valueColor={failCount > 0 ? 'var(--color-danger)' : 'var(--color-text-secondary)'}
            />
            <SummaryCard
              label="With Honors"
              value={String(highHonorsCount)}
              sub="GWA ≤ 1.50"
              valueColor="var(--color-primary)"
            />
          </div>

          {/* Two-column layout: student table + grade scale reference */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {/* Student GWA table */}
            <div className="xl:col-span-2">
              <h2 className="mb-3" style={{ fontSize: '15px', fontWeight: 600, color: 'var(--color-text-primary)' }}>
                Student GWA Summary
              </h2>
              <div
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderRadius: 'var(--radius-card)',
                  boxShadow: 'var(--shadow-card)',
                  overflow: 'hidden',
                }}
              >
                <table style={{ width: '100%', fontSize: '13px' }}>
                  <thead>
                    <tr style={{ backgroundColor: 'var(--color-surface-alt)', borderBottom: '1px solid var(--color-border)' }}>
                      <Th>#</Th>
                      <Th align="left">Student</Th>
                      {SUBJECTS.map((s) => <Th key={s}>{s}</Th>)}
                      <Th>GWA</Th>
                      <Th align="left">Remark</Th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((stu, i) => (
                      <tr
                        key={stu.name}
                        onClick={() => setSelectedStudent(selectedStudent === i ? null : i)}
                        className="cursor-pointer"
                        style={{
                          borderBottom: i < students.length - 1 ? '1px solid var(--color-border)' : 'none',
                          backgroundColor: selectedStudent === i ? 'var(--color-primary-soft)' : 'transparent',
                          transition: 'background-color 0.1s',
                        }}
                        onMouseEnter={(e) => { if (selectedStudent !== i) e.currentTarget.style.backgroundColor = 'var(--color-primary-soft)'; }}
                        onMouseLeave={(e) => { if (selectedStudent !== i) e.currentTarget.style.backgroundColor = 'transparent'; }}
                      >
                        <td style={{ padding: '10px 12px', fontFamily: 'var(--font-data)', color: 'var(--color-text-secondary)', textAlign: 'center' }}>
                          {String(i + 1).padStart(2, '0')}
                        </td>
                        <td style={{ padding: '10px 12px', fontWeight: 500, color: 'var(--color-text-primary)' }}>
                          {stu.name}
                        </td>
                        {stu.converted.map((c, si) => (
                          <td key={si} style={{ padding: '10px 12px', textAlign: 'center', fontFamily: 'var(--font-data)', color: gwaColor(c.grade) }}>
                            {c.grade.toFixed(2)}
                          </td>
                        ))}
                        <td style={{ padding: '10px 12px', textAlign: 'center' }}>
                          <span
                            style={{
                              display: 'inline-block',
                              padding: '2px 8px',
                              borderRadius: 'var(--radius-pill)',
                              backgroundColor: gwaColorSoft(stu.gwa),
                              color: gwaColor(stu.gwa),
                              fontFamily: 'var(--font-data)',
                              fontWeight: 600,
                              fontSize: '12px',
                            }}
                          >
                            {stu.gwa.toFixed(2)}
                          </span>
                        </td>
                        <td style={{ padding: '10px 12px', fontSize: '12px', color: gwaColor(stu.gwa), fontWeight: 500 }}>
                          {stu.remark}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Right column: reference + selected student detail */}
            <div className="space-y-6">
              {/* Selected student detail */}
              {sel && (
                <div
                  style={{
                    backgroundColor: 'var(--color-surface)',
                    borderRadius: 'var(--radius-card)',
                    boxShadow: 'var(--shadow-elevated)',
                    border: '1px solid var(--color-primary-soft)',
                    overflow: 'hidden',
                  }}
                >
                  <div
                    className="px-4 py-3"
                    style={{ backgroundColor: 'var(--color-primary-soft)', borderBottom: '1px solid var(--color-border)' }}
                  >
                    <p style={{ fontSize: '11px', fontWeight: 600, color: 'var(--color-primary)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                      STUDENT DETAIL
                    </p>
                    <p style={{ fontSize: '14px', fontWeight: 600, color: 'var(--color-text-primary)', marginTop: '2px' }}>
                      {sel.name}
                    </p>
                  </div>
                  <div className="p-4">
                    <div className="space-y-3 mb-4">
                      {SUBJECTS.map((subj, i) => (
                        <div key={subj} className="flex items-center justify-between">
                          <span style={{ fontSize: '13px', color: 'var(--color-text-secondary)' }}>{subj}</span>
                          <div className="flex items-center gap-3">
                            <span style={{ fontSize: '12px', color: 'var(--color-text-secondary)', fontFamily: 'var(--font-data)' }}>
                              {sel.scores[i]}/{ITEMS_TOTAL} ({sel.percentages[i]}%)
                            </span>
                            <span
                              style={{
                                fontSize: '13px',
                                fontFamily: 'var(--font-data)',
                                fontWeight: 600,
                                color: gwaColor(sel.converted[i].grade),
                                minWidth: '36px',
                                textAlign: 'right',
                              }}
                            >
                              {sel.converted[i].grade.toFixed(2)}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div
                      className="flex items-center justify-between pt-3"
                      style={{ borderTop: '1px solid var(--color-border)' }}
                    >
                      <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--color-text-primary)' }}>GWA</span>
                      <div className="flex items-center gap-2">
                        <span
                          style={{
                            padding: '3px 10px',
                            borderRadius: 'var(--radius-pill)',
                            backgroundColor: gwaColorSoft(sel.gwa),
                            color: gwaColor(sel.gwa),
                            fontFamily: 'var(--font-data)',
                            fontWeight: 700,
                            fontSize: '14px',
                          }}
                        >
                          {sel.gwa.toFixed(2)}
                        </span>
                        <span style={{ fontSize: '12px', color: gwaColor(sel.gwa), fontWeight: 500 }}>{sel.remark}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Philippine Grade Scale Reference */}
              <div
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderRadius: 'var(--radius-card)',
                  boxShadow: 'var(--shadow-card)',
                  overflow: 'hidden',
                }}
              >
                <div className="px-4 py-3" style={{ borderBottom: '1px solid var(--color-border)', backgroundColor: 'var(--color-surface-alt)' }}>
                  <p style={{ fontSize: '12px', fontWeight: 600, color: 'var(--color-text-secondary)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                    PHILIPPINE GRADING SCALE
                  </p>
                </div>
                <table style={{ width: '100%', fontSize: '12px' }}>
                  <thead>
                    <tr style={{ backgroundColor: 'var(--color-surface-alt)' }}>
                      <th style={{ padding: '8px 12px', textAlign: 'center', fontWeight: 500, color: 'var(--color-text-secondary)', fontSize: '11px' }}>Grade</th>
                      <th style={{ padding: '8px 12px', textAlign: 'center', fontWeight: 500, color: 'var(--color-text-secondary)', fontSize: '11px' }}>Range</th>
                      <th style={{ padding: '8px 12px', textAlign: 'left', fontWeight: 500, color: 'var(--color-text-secondary)', fontSize: '11px' }}>Remark</th>
                    </tr>
                  </thead>
                  <tbody>
                    {GRADE_SCALE.map((row, i) => (
                      <tr
                        key={row.grade}
                        style={{ borderTop: i > 0 ? '1px solid var(--color-border)' : 'none' }}
                      >
                        <td style={{ padding: '7px 12px', textAlign: 'center', fontFamily: 'var(--font-data)', fontWeight: 600, color: gwaColor(row.grade) }}>
                          {row.grade.toFixed(2)}
                        </td>
                        <td style={{ padding: '7px 12px', textAlign: 'center', fontFamily: 'var(--font-data)', color: 'var(--color-text-secondary)', fontSize: '11px' }}>
                          {row.max === 100 ? `${row.min}–100%` : row.min === 0 ? `Below ${row.max + 1}%` : `${row.min}–${row.max}%`}
                        </td>
                        <td style={{ padding: '7px 12px', color: gwaColor(row.grade), fontWeight: 500 }}>
                          {row.remark}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Grade distribution */}
              <div
                style={{
                  backgroundColor: 'var(--color-surface)',
                  borderRadius: 'var(--radius-card)',
                  boxShadow: 'var(--shadow-card)',
                  padding: '16px',
                }}
              >
                <p className="mb-3" style={{ fontSize: '12px', fontWeight: 600, color: 'var(--color-text-secondary)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  CLASS DISTRIBUTION
                </p>
                <GradeDistribution students={students} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SummaryCard({
  label, value, sub, valueColor, large,
}: {
  label: string; value: string; sub: string; valueColor: string; large?: boolean;
}) {
  return (
    <div
      style={{
        backgroundColor: 'var(--color-surface)',
        borderRadius: 'var(--radius-card)',
        boxShadow: 'var(--shadow-card)',
        padding: '20px',
      }}
    >
      <p
        className="mb-2"
        style={{ fontSize: '12px', fontWeight: 500, color: 'var(--color-text-secondary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}
      >
        {label}
      </p>
      <div
        className="mb-1"
        style={{
          fontFamily: 'var(--font-display)',
          fontSize: large ? '48px' : '40px',
          color: valueColor,
          lineHeight: 1,
        }}
      >
        {value}
      </div>
      <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)' }}>{sub}</p>
    </div>
  );
}

function Th({ children, align = 'center' }: { children?: React.ReactNode; align?: 'left' | 'center' | 'right' }) {
  return (
    <th
      style={{
        padding: '10px 12px',
        textAlign: align,
        fontSize: '11px',
        fontWeight: 500,
        color: 'var(--color-text-secondary)',
        textTransform: 'uppercase',
        letterSpacing: '0.05em',
        whiteSpace: 'nowrap',
      }}
    >
      {children}
    </th>
  );
}

type StudentRecord = { gwa: number };

function GradeDistribution({ students }: { students: StudentRecord[] }) {
  const buckets = [
    { label: '1.00–1.25', min: 1.00, max: 1.25, color: 'var(--color-success)' },
    { label: '1.50–1.75', min: 1.26, max: 1.75, color: 'var(--color-success)' },
    { label: '2.00–2.25', min: 1.76, max: 2.25, color: 'var(--color-warning)' },
    { label: '2.50–2.75', min: 2.26, max: 2.75, color: 'var(--color-warning)' },
    { label: '3.00',       min: 2.76, max: 3.00, color: 'var(--color-text-secondary)' },
    { label: '5.00 (Failed)', min: 3.01, max: 5.00, color: 'var(--color-danger)' },
  ];
  const max = Math.max(...buckets.map((b) => students.filter((s) => s.gwa >= b.min && s.gwa <= b.max).length), 1);
  return (
    <div className="space-y-2">
      {buckets.map((b) => {
        const count = students.filter((s) => s.gwa >= b.min && s.gwa <= b.max).length;
        const pct = (count / max) * 100;
        return (
          <div key={b.label} className="flex items-center gap-2">
            <span style={{ fontSize: '11px', fontFamily: 'var(--font-data)', color: 'var(--color-text-secondary)', minWidth: '80px' }}>{b.label}</span>
            <div style={{ flex: 1, height: '8px', backgroundColor: 'var(--color-surface-alt)', borderRadius: '4px', overflow: 'hidden' }}>
              <div
                style={{
                  height: '100%',
                  width: `${pct}%`,
                  backgroundColor: b.color,
                  borderRadius: '4px',
                  transition: 'width 0.4s ease',
                }}
              />
            </div>
            <span style={{ fontSize: '11px', fontFamily: 'var(--font-data)', color: 'var(--color-text-secondary)', minWidth: '16px', textAlign: 'right' }}>{count}</span>
          </div>
        );
      })}
    </div>
  );
}
