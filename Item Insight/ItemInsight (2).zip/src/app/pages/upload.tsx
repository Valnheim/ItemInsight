import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Upload as UploadIcon, User, Columns3, CreditCard, Download, CheckCircle, X } from 'lucide-react';

export default function Upload() {
  const navigate = useNavigate();
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && droppedFile.name.endsWith('.csv')) {
      setFile(droppedFile);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
    }
  };

  const removeFile = () => {
    setFile(null);
  };

  return (
    <div
      className="min-h-screen p-6"
      style={{
        backgroundColor: 'var(--color-bg)',
        fontFamily: 'var(--font-body)',
      }}
    >
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-[1fr,320px] gap-6">
          {/* Left panel - Upload zone */}
          <div>
            <div
              style={{
                backgroundColor: 'var(--color-surface)',
                borderRadius: 'var(--radius-card)',
                boxShadow: 'var(--shadow-card)',
                padding: '32px',
              }}
            >
              <h1
                className="mb-6"
                style={{
                  fontFamily: 'var(--font-body)',
                  fontSize: '20px',
                  fontWeight: 600,
                  color: 'var(--color-text-primary)',
                }}
              >
                Upload Student Responses
              </h1>

              {/* Upload zone */}
              {!file ? (
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  className="relative cursor-pointer transition-all"
                  style={{
                    border: `2px dashed ${isDragging ? 'var(--color-primary)' : 'var(--color-border)'}`,
                    backgroundColor: isDragging
                      ? 'var(--color-primary-soft)'
                      : 'var(--color-surface-alt)',
                    borderRadius: 'var(--radius-card)',
                    padding: '48px 24px',
                    textAlign: 'center',
                  }}
                  onClick={() => document.getElementById('file-input')?.click()}
                >
                  <UploadIcon
                    size={48}
                    style={{
                      margin: '0 auto 16px',
                      color: 'var(--color-text-secondary)',
                    }}
                  />
                  <p
                    style={{
                      fontSize: '14px',
                      color: 'var(--color-text-primary)',
                      marginBottom: '4px',
                    }}
                  >
                    Drop your CSV file here
                  </p>
                  <p
                    style={{
                      fontSize: '14px',
                      color: 'var(--color-primary)',
                      textDecoration: 'underline',
                    }}
                  >
                    or click to browse
                  </p>
                  <input
                    id="file-input"
                    type="file"
                    accept=".csv"
                    onChange={handleFileSelect}
                    style={{ display: 'none' }}
                  />
                </div>
              ) : (
                <div
                  className="flex items-center justify-between p-4 transition-all"
                  style={{
                    backgroundColor: 'var(--color-success-soft)',
                    border: '1px solid var(--color-success)',
                    borderRadius: 'var(--radius-card)',
                  }}
                >
                  <div className="flex items-center gap-3">
                    <CheckCircle size={24} style={{ color: 'var(--color-success)' }} />
                    <div>
                      <p
                        style={{
                          fontSize: '14px',
                          fontWeight: 500,
                          color: 'var(--color-text-primary)',
                        }}
                      >
                        {file.name}
                      </p>
                      <p
                        style={{
                          fontSize: '12px',
                          color: 'var(--color-text-secondary)',
                        }}
                      >
                        {(file.size / 1024).toFixed(1)} KB
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={removeFile}
                    className="transition-colors"
                    style={{
                      background: 'none',
                      border: 'none',
                      color: 'var(--color-text-secondary)',
                      cursor: 'pointer',
                      padding: '4px',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.color = 'var(--color-danger)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.color = 'var(--color-text-secondary)';
                    }}
                  >
                    <X size={20} />
                  </button>
                </div>
              )}

              {/* Expected format note */}
              <p
                className="mt-4 mb-6"
                style={{
                  fontSize: '12px',
                  color: 'var(--color-text-secondary)',
                }}
              >
                Expected format: one row per student, one column per item. First column = Student ID.
              </p>

              {/* Sample CSV preview */}
              <div>
                <p
                  className="mb-2"
                  style={{
                    fontSize: '12px',
                    fontWeight: 500,
                    color: 'var(--color-text-secondary)',
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                  }}
                >
                  Sample CSV Format
                </p>
                <div
                  style={{
                    border: '1px solid var(--color-border)',
                    borderRadius: 'var(--radius-inner)',
                    overflow: 'hidden',
                  }}
                >
                  <table style={{ width: '100%', fontSize: '12px' }}>
                    <tbody>
                      <tr style={{ backgroundColor: 'var(--color-surface-alt)' }}>
                        <td
                          style={{
                            padding: '8px',
                            fontFamily: 'var(--font-data)',
                            borderRight: '1px solid var(--color-border)',
                          }}
                        >
                          S001
                        </td>
                        <td
                          style={{
                            padding: '8px',
                            fontFamily: 'var(--font-data)',
                            borderRight: '1px solid var(--color-border)',
                          }}
                        >
                          A
                        </td>
                        <td
                          style={{
                            padding: '8px',
                            fontFamily: 'var(--font-data)',
                            borderRight: '1px solid var(--color-border)',
                          }}
                        >
                          B
                        </td>
                        <td
                          style={{
                            padding: '8px',
                            fontFamily: 'var(--font-data)',
                            borderRight: '1px solid var(--color-border)',
                          }}
                        >
                          C
                        </td>
                        <td style={{ padding: '8px', fontFamily: 'var(--font-data)' }}>D</td>
                      </tr>
                      <tr>
                        <td
                          style={{
                            padding: '8px',
                            fontFamily: 'var(--font-data)',
                            borderRight: '1px solid var(--color-border)',
                          }}
                        >
                          S002
                        </td>
                        <td
                          style={{
                            padding: '8px',
                            fontFamily: 'var(--font-data)',
                            borderRight: '1px solid var(--color-border)',
                          }}
                        >
                          B
                        </td>
                        <td
                          style={{
                            padding: '8px',
                            fontFamily: 'var(--font-data)',
                            borderRight: '1px solid var(--color-border)',
                          }}
                        >
                          B
                        </td>
                        <td
                          style={{
                            padding: '8px',
                            fontFamily: 'var(--font-data)',
                            borderRight: '1px solid var(--color-border)',
                          }}
                        >
                          A
                        </td>
                        <td style={{ padding: '8px', fontFamily: 'var(--font-data)' }}>D</td>
                      </tr>
                      <tr style={{ backgroundColor: 'var(--color-surface-alt)' }}>
                        <td
                          style={{
                            padding: '8px',
                            fontFamily: 'var(--font-data)',
                            borderRight: '1px solid var(--color-border)',
                          }}
                        >
                          S003
                        </td>
                        <td
                          style={{
                            padding: '8px',
                            fontFamily: 'var(--font-data)',
                            borderRight: '1px solid var(--color-border)',
                          }}
                        >
                          A
                        </td>
                        <td
                          style={{
                            padding: '8px',
                            fontFamily: 'var(--font-data)',
                            borderRight: '1px solid var(--color-border)',
                          }}
                        >
                          A
                        </td>
                        <td
                          style={{
                            padding: '8px',
                            fontFamily: 'var(--font-data)',
                            borderRight: '1px solid var(--color-border)',
                          }}
                        >
                          C
                        </td>
                        <td style={{ padding: '8px', fontFamily: 'var(--font-data)' }}>B</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Analyze button */}
              {file && (
                <button
                  onClick={() => navigate('/dashboard')}
                  className="w-full mt-6 transition-all"
                  style={{
                    backgroundColor: 'var(--color-primary)',
                    color: 'white',
                    padding: '12px',
                    borderRadius: 'var(--radius-button)',
                    border: 'none',
                    fontSize: '14px',
                    fontWeight: 500,
                    cursor: 'pointer',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.boxShadow = 'var(--shadow-button-hover)';
                    e.currentTarget.style.transform = 'translateY(-1px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.boxShadow = 'none';
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}
                >
                  Analyze Test
                </button>
              )}
            </div>
          </div>

          {/* Right panel - Instructions */}
          <div
            style={{
              backgroundColor: 'var(--color-surface-alt)',
              borderRadius: 'var(--radius-card)',
              borderLeft: '4px solid var(--color-primary)',
              padding: '24px',
            }}
          >
            <h2
              className="mb-4"
              style={{
                fontFamily: 'var(--font-body)',
                fontSize: '15px',
                fontWeight: 600,
                color: 'var(--color-text-primary)',
              }}
            >
              How to prepare your file
            </h2>

            <div className="space-y-4">
              <div className="flex gap-3">
                <User
                  size={20}
                  style={{ color: 'var(--color-primary)', flexShrink: 0 }}
                />
                <div>
                  <p
                    style={{
                      fontSize: '14px',
                      color: 'var(--color-text-primary)',
                      marginBottom: '2px',
                    }}
                  >
                    One row per student
                  </p>
                  <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)' }}>
                    Each student's answers on one line
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <Columns3
                  size={20}
                  style={{ color: 'var(--color-primary)', flexShrink: 0 }}
                />
                <div>
                  <p
                    style={{
                      fontSize: '14px',
                      color: 'var(--color-text-primary)',
                      marginBottom: '2px',
                    }}
                  >
                    One column per test item
                  </p>
                  <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)' }}>
                    Item 1, Item 2, Item 3, etc.
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <CreditCard
                  size={20}
                  style={{ color: 'var(--color-primary)', flexShrink: 0 }}
                />
                <div>
                  <p
                    style={{
                      fontSize: '14px',
                      color: 'var(--color-text-primary)',
                      marginBottom: '2px',
                    }}
                  >
                    Student ID in the first column
                  </p>
                  <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)' }}>
                    Any unique identifier works
                  </p>
                </div>
              </div>
            </div>

            <button
              className="mt-6 transition-colors"
              style={{
                background: 'none',
                border: 'none',
                color: 'var(--color-primary)',
                fontSize: '14px',
                fontWeight: 500,
                cursor: 'pointer',
                textDecoration: 'underline',
                padding: 0,
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = 'var(--color-text-primary)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = 'var(--color-primary)';
              }}
            >
              <Download size={14} style={{ display: 'inline', marginRight: '4px' }} />
              Download sample CSV
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
