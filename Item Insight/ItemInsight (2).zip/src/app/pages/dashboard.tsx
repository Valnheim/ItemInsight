import { useState } from 'react';
import { useNavigate } from 'react-router';
import { FileText, BarChart3, List, FileSpreadsheet, GraduationCap } from 'lucide-react';
import { AppLogo } from '../components/app-logo';
import { HealthBar } from '../components/health-bar';
import { ItemDetailPanel } from '../components/item-detail-panel';

export default function Dashboard() {
  const navigate = useNavigate();
  const [activeNav, setActiveNav] = useState('overview');
  const [selectedItem, setSelectedItem] = useState<number | null>(null);

  const itemsData = [
    { item: 1, key: 'A', difficulty: 0.74, discrimination: 0.41, status: 'Good', statusColor: 'success' },
    { item: 2, key: 'C', difficulty: 0.23, discrimination: 0.18, status: 'Too Hard / Poor Disc.', statusColor: 'danger' },
    { item: 3, key: 'B', difficulty: 0.91, discrimination: 0.12, status: 'Too Easy', statusColor: 'danger' },
    { item: 4, key: 'D', difficulty: 0.55, discrimination: 0.37, status: 'Good', statusColor: 'success' },
    { item: 5, key: 'A', difficulty: 0.48, discrimination: 0.29, status: 'Good', statusColor: 'success' },
    { item: 6, key: 'C', difficulty: 0.17, discrimination: 0.09, status: 'Too Hard / Poor Disc.', statusColor: 'danger' },
    { item: 7, key: 'B', difficulty: 0.68, discrimination: 0.44, status: 'Good', statusColor: 'success' },
    { item: 8, key: 'A', difficulty: 0.88, discrimination: 0.11, status: 'Too Easy', statusColor: 'danger' },
  ];

  return (
    <div
      className="min-h-screen flex"
      style={{
        backgroundColor: 'var(--color-bg)',
        fontFamily: 'var(--font-body)',
      }}
    >
      {/* Sidebar */}
      <div
        className="flex-shrink-0"
        style={{
          width: '240px',
          backgroundColor: 'var(--color-surface-alt)',
          borderRight: '1px solid var(--color-border)',
          padding: '24px',
        }}
      >
        {/* Logo */}
        <div className="mb-8">
          <AppLogo size="small" />
        </div>

        {/* Navigation */}
        <div className="mb-8">
          <p
            className="mb-2"
            style={{
              fontSize: '12px',
              fontWeight: 500,
              color: 'var(--color-text-secondary)',
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
            }}
          >
            ANALYSIS
          </p>
          <nav className="space-y-1">
            {[
              { id: 'overview', label: 'Overview', icon: BarChart3 },
              { id: 'items', label: 'Item Results', icon: List },
              { id: 'distractors', label: 'Distractor Detail', icon: FileSpreadsheet },
              { id: 'gwa', label: 'GWA Analysis', icon: GraduationCap },
              { id: 'report', label: 'Report', icon: FileText },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    if (item.id === 'report') {
                      navigate('/report');
                    } else if (item.id === 'gwa') {
                      navigate('/gwa');
                    } else {
                      setActiveNav(item.id);
                    }
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 transition-all"
                  style={{
                    backgroundColor:
                      activeNav === item.id ? 'var(--color-primary-soft)' : 'transparent',
                    color:
                      activeNav === item.id
                        ? 'var(--color-primary)'
                        : 'var(--color-text-secondary)',
                    borderRadius: 'var(--radius-inner)',
                    border: 'none',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: 500,
                    textAlign: 'left',
                  }}
                  onMouseEnter={(e) => {
                    if (activeNav !== item.id) {
                      e.currentTarget.style.backgroundColor = 'var(--color-surface)';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (activeNav !== item.id) {
                      e.currentTarget.style.backgroundColor = 'transparent';
                    }
                  }}
                >
                  <Icon size={16} />
                  {item.label}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Test metadata card */}
        <div
          style={{
            backgroundColor: 'var(--color-surface)',
            border: '1px solid var(--color-border)',
            borderRadius: 'var(--radius-inner)',
            padding: '12px',
          }}
        >
          <p
            className="mb-1"
            style={{
              fontSize: '13px',
              fontWeight: 600,
              color: 'var(--color-text-primary)',
            }}
          >
            Q2 Science Exam
          </p>
          <div
            className="flex items-center gap-2 mb-1"
            style={{ fontSize: '12px', color: 'var(--color-text-secondary)' }}
          >
            <span>Items: <span style={{ fontFamily: 'var(--font-data)' }}>20</span></span>
            <span>|</span>
            <span>Students: <span style={{ fontFamily: 'var(--font-data)' }}>35</span></span>
          </div>
          <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>
            Date analyzed: June 26, 2026
          </p>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 p-8 overflow-y-auto">
        {/* Page header */}
        <div className="mb-6">
          <h1
            style={{
              fontFamily: 'var(--font-body)',
              fontSize: '20px',
              fontWeight: 600,
              color: 'var(--color-text-primary)',
              marginBottom: '4px',
            }}
          >
            Analysis Overview
          </h1>
          <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)' }}>
            Q2 Science Exam · 35 students · 20 items
          </p>
        </div>

        {/* Summary stat cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {/* Card 1 */}
          <div
            style={{
              backgroundColor: 'var(--color-surface)',
              borderRadius: 'var(--radius-card)',
              boxShadow: 'var(--shadow-card)',
              padding: '20px',
            }}
          >
            <p
              className="mb-2"
              style={{
                fontSize: '12px',
                fontWeight: 500,
                color: 'var(--color-text-secondary)',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              AVG. DIFFICULTY
            </p>
            <div
              className="mb-2"
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '48px',
                color: 'var(--color-text-primary)',
                lineHeight: 1,
              }}
            >
              0.62
            </div>
            <p
              className="mb-1"
              style={{ fontSize: '13px', color: 'var(--color-success)', fontWeight: 500 }}
            >
              Acceptable range
            </p>
            <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>
              Items in good range: 14
            </p>
          </div>

          {/* Card 2 */}
          <div
            style={{
              backgroundColor: 'var(--color-surface)',
              borderRadius: 'var(--radius-card)',
              boxShadow: 'var(--shadow-card)',
              padding: '20px',
            }}
          >
            <p
              className="mb-2"
              style={{
                fontSize: '12px',
                fontWeight: 500,
                color: 'var(--color-text-secondary)',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              AVG. DISCRIMINATION
            </p>
            <div
              className="mb-2"
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '48px',
                color: 'var(--color-text-primary)',
                lineHeight: 1,
              }}
            >
              0.34
            </div>
            <p
              className="mb-1"
              style={{ fontSize: '13px', color: 'var(--color-warning)', fontWeight: 500 }}
            >
              Moderate
            </p>
            <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>
              Strong items: 11
            </p>
          </div>

          {/* Card 3 */}
          <div
            style={{
              backgroundColor: 'var(--color-surface)',
              borderRadius: 'var(--radius-card)',
              boxShadow: 'var(--shadow-card)',
              padding: '20px',
            }}
          >
            <p
              className="mb-2"
              style={{
                fontSize: '12px',
                fontWeight: 500,
                color: 'var(--color-text-secondary)',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              ITEMS FLAGGED
            </p>
            <div
              className="mb-2"
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '48px',
                color: 'var(--color-text-primary)',
                lineHeight: 1,
              }}
            >
              6
            </div>
            <p
              className="mb-2"
              style={{ fontSize: '13px', color: 'var(--color-danger)', fontWeight: 500 }}
            >
              Need review
            </p>
            <div className="flex flex-wrap gap-1">
              <span
                style={{
                  fontSize: '10px',
                  padding: '2px 6px',
                  borderRadius: 'var(--radius-pill)',
                  backgroundColor: 'var(--color-danger-soft)',
                  color: 'var(--color-danger)',
                }}
              >
                2 Too Hard
              </span>
              <span
                style={{
                  fontSize: '10px',
                  padding: '2px 6px',
                  borderRadius: 'var(--radius-pill)',
                  backgroundColor: 'var(--color-warning-soft)',
                  color: 'var(--color-warning)',
                }}
              >
                1 Borderline
              </span>
              <span
                style={{
                  fontSize: '10px',
                  padding: '2px 6px',
                  borderRadius: 'var(--radius-pill)',
                  backgroundColor: 'var(--color-danger-soft)',
                  color: 'var(--color-danger)',
                }}
              >
                3 Poor Disc.
              </span>
            </div>
          </div>

          {/* Card 4 */}
          <div
            style={{
              backgroundColor: 'var(--color-surface)',
              borderRadius: 'var(--radius-card)',
              boxShadow: 'var(--shadow-card)',
              padding: '20px',
            }}
          >
            <p
              className="mb-2"
              style={{
                fontSize: '12px',
                fontWeight: 500,
                color: 'var(--color-text-secondary)',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              TEST QUALITY
            </p>
            <div
              className="mb-2"
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '32px',
                color: 'var(--color-warning)',
                lineHeight: 1.2,
              }}
            >
              Acceptable
            </div>
            <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>
              Some items need revision
            </p>
          </div>
        </div>

        {/* Item-by-Item Breakdown */}
        <div>
          <h2
            className="mb-4"
            style={{
              fontFamily: 'var(--font-body)',
              fontSize: '20px',
              fontWeight: 600,
              color: 'var(--color-text-primary)',
            }}
          >
            Item-by-Item Breakdown
          </h2>

          <div
            style={{
              backgroundColor: 'var(--color-surface)',
              borderRadius: 'var(--radius-card)',
              boxShadow: 'var(--shadow-card)',
              overflow: 'hidden',
            }}
          >
            <table style={{ width: '100%', fontSize: '14px' }}>
              <thead>
                <tr
                  style={{
                    backgroundColor: 'var(--color-surface-alt)',
                    borderBottom: '1px solid var(--color-border)',
                  }}
                >
                  <th
                    style={{
                      padding: '12px 16px',
                      textAlign: 'left',
                      fontSize: '12px',
                      fontWeight: 500,
                      color: 'var(--color-text-secondary)',
                      textTransform: 'uppercase',
                      letterSpacing: '0.05em',
                    }}
                  >
                    Item #
                  </th>
                  <th
                    style={{
                      padding: '12px 16px',
                      textAlign: 'left',
                      fontSize: '12px',
                      fontWeight: 500,
                      color: 'var(--color-text-secondary)',
                      textTransform: 'uppercase',
                      letterSpacing: '0.05em',
                    }}
                  >
                    Key
                  </th>
                  <th
                    style={{
                      padding: '12px 16px',
                      textAlign: 'left',
                      fontSize: '12px',
                      fontWeight: 500,
                      color: 'var(--color-text-secondary)',
                      textTransform: 'uppercase',
                      letterSpacing: '0.05em',
                    }}
                  >
                    Difficulty (p)
                  </th>
                  <th
                    style={{
                      padding: '12px 16px',
                      textAlign: 'left',
                      fontSize: '12px',
                      fontWeight: 500,
                      color: 'var(--color-text-secondary)',
                      textTransform: 'uppercase',
                      letterSpacing: '0.05em',
                      width: '160px',
                    }}
                  >
                    Health Bar
                  </th>
                  <th
                    style={{
                      padding: '12px 16px',
                      textAlign: 'left',
                      fontSize: '12px',
                      fontWeight: 500,
                      color: 'var(--color-text-secondary)',
                      textTransform: 'uppercase',
                      letterSpacing: '0.05em',
                    }}
                  >
                    Discrimination (D)
                  </th>
                  <th
                    style={{
                      padding: '12px 16px',
                      textAlign: 'left',
                      fontSize: '12px',
                      fontWeight: 500,
                      color: 'var(--color-text-secondary)',
                      textTransform: 'uppercase',
                      letterSpacing: '0.05em',
                    }}
                  >
                    Status
                  </th>
                </tr>
              </thead>
              <tbody>
                {itemsData.map((item, index) => (
                  <tr
                    key={item.item}
                    onClick={() => setSelectedItem(item.item)}
                    className="cursor-pointer transition-all group"
                    style={{
                      borderBottom:
                        index < itemsData.length - 1 ? '1px solid var(--color-border)' : 'none',
                      backgroundColor:
                        selectedItem === item.item ? 'var(--color-primary-soft)' : 'transparent',
                    }}
                    onMouseEnter={(e) => {
                      if (selectedItem !== item.item) {
                        e.currentTarget.style.backgroundColor = 'var(--color-primary-soft)';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (selectedItem !== item.item) {
                        e.currentTarget.style.backgroundColor = 'transparent';
                      }
                    }}
                  >
                    <td
                      style={{
                        padding: '12px 16px',
                        fontFamily: 'var(--font-data)',
                        fontWeight: 500,
                      }}
                    >
                      {String(item.item).padStart(2, '0')}
                    </td>
                    <td
                      style={{
                        padding: '12px 16px',
                        fontFamily: 'var(--font-data)',
                        fontWeight: 500,
                      }}
                    >
                      {item.key}
                    </td>
                    <td
                      style={{
                        padding: '12px 16px',
                        fontFamily: 'var(--font-data)',
                        fontWeight: 500,
                      }}
                    >
                      {item.difficulty.toFixed(2)}
                    </td>
                    <td style={{ padding: '12px 16px' }}>
                      <HealthBar value={item.difficulty} size="small" />
                    </td>
                    <td
                      style={{
                        padding: '12px 16px',
                        fontFamily: 'var(--font-data)',
                        fontWeight: 500,
                      }}
                    >
                      {item.discrimination.toFixed(2)}
                    </td>
                    <td style={{ padding: '12px 16px' }}>
                      <span
                        className="inline-flex items-center gap-1"
                        style={{
                          padding: '4px 12px',
                          borderRadius: 'var(--radius-pill)',
                          backgroundColor:
                            item.statusColor === 'success'
                              ? 'var(--color-success-soft)'
                              : item.statusColor === 'warning'
                              ? 'var(--color-warning-soft)'
                              : 'var(--color-danger-soft)',
                          color:
                            item.statusColor === 'success'
                              ? 'var(--color-success)'
                              : item.statusColor === 'warning'
                              ? 'var(--color-warning)'
                              : 'var(--color-danger)',
                          fontSize: '12px',
                          fontWeight: 500,
                        }}
                      >
                        <span
                          style={{
                            width: '6px',
                            height: '6px',
                            borderRadius: '50%',
                            backgroundColor:
                              item.statusColor === 'success'
                                ? 'var(--color-success)'
                                : item.statusColor === 'warning'
                                ? 'var(--color-warning)'
                                : 'var(--color-danger)',
                          }}
                        />
                        {item.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Item detail panel */}
      <ItemDetailPanel
        isOpen={selectedItem !== null}
        onClose={() => setSelectedItem(null)}
        itemNumber={selectedItem || 2}
      />
    </div>
  );
}
