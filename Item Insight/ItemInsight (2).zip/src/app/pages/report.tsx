import { useNavigate } from 'react-router';
import { ArrowLeft, Printer } from 'lucide-react';

export default function Report() {
  const navigate = useNavigate();

  const allItems = [
    { item: 1, key: 'A', difficulty: 0.74, discrimination: 0.41, status: 'Good' },
    { item: 2, key: 'C', difficulty: 0.23, discrimination: 0.18, status: 'Too Hard' },
    { item: 3, key: 'B', difficulty: 0.91, discrimination: 0.12, status: 'Too Easy' },
    { item: 4, key: 'D', difficulty: 0.55, discrimination: 0.37, status: 'Good' },
    { item: 5, key: 'A', difficulty: 0.48, discrimination: 0.29, status: 'Good' },
    { item: 6, key: 'C', difficulty: 0.17, discrimination: 0.09, status: 'Too Hard' },
    { item: 7, key: 'B', difficulty: 0.68, discrimination: 0.44, status: 'Good' },
    { item: 8, key: 'A', difficulty: 0.88, discrimination: 0.11, status: 'Too Easy' },
    { item: 9, key: 'D', difficulty: 0.62, discrimination: 0.38, status: 'Good' },
    { item: 10, key: 'C', difficulty: 0.71, discrimination: 0.42, status: 'Good' },
    { item: 11, key: 'B', difficulty: 0.45, discrimination: 0.31, status: 'Good' },
    { item: 12, key: 'A', difficulty: 0.58, discrimination: 0.35, status: 'Good' },
    { item: 13, key: 'D', difficulty: 0.19, discrimination: 0.14, status: 'Too Hard' },
    { item: 14, key: 'C', difficulty: 0.77, discrimination: 0.39, status: 'Good' },
    { item: 15, key: 'B', difficulty: 0.52, discrimination: 0.33, status: 'Good' },
    { item: 16, key: 'A', difficulty: 0.64, discrimination: 0.36, status: 'Good' },
    { item: 17, key: 'D', difficulty: 0.41, discrimination: 0.28, status: 'Good' },
    { item: 18, key: 'C', difficulty: 0.69, discrimination: 0.40, status: 'Good' },
    { item: 19, key: 'B', difficulty: 0.84, discrimination: 0.15, status: 'Too Easy' },
    { item: 20, key: 'A', difficulty: 0.56, discrimination: 0.34, status: 'Good' },
  ];

  return (
    <div
      className="min-h-screen p-6"
      style={{
        backgroundColor: 'var(--color-bg)',
        fontFamily: 'var(--font-body)',
      }}
    >
      {/* Action bar */}
      <div className="max-w-[800px] mx-auto mb-4 flex items-center justify-between print:hidden">
        <button
          onClick={() => navigate('/dashboard')}
          className="flex items-center gap-2 transition-colors"
          style={{
            color: 'var(--color-primary)',
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            fontSize: '14px',
            padding: 0,
            fontWeight: 500,
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.color = 'var(--color-text-primary)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.color = 'var(--color-primary)';
          }}
        >
          <ArrowLeft size={16} />
          Back to Dashboard
        </button>

        <button
          onClick={() => window.print()}
          className="flex items-center gap-2 px-4 py-2 transition-all"
          style={{
            backgroundColor: 'var(--color-primary)',
            color: 'white',
            borderRadius: 'var(--radius-button)',
            border: 'none',
            fontSize: '14px',
            fontWeight: 500,
            cursor: 'pointer',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.boxShadow = 'var(--shadow-button-hover)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.boxShadow = 'none';
          }}
        >
          <Printer size={16} />
          Print Report
        </button>
      </div>

      {/* Report content */}
      <div
        className="max-w-[800px] mx-auto p-12"
        style={{
          backgroundColor: 'var(--color-surface)',
          borderRadius: 'var(--radius-card)',
          boxShadow: 'var(--shadow-card)',
        }}
      >
        {/* Header */}
        <div
          className="flex items-start gap-4 pb-6 mb-6"
          style={{ borderBottom: '2px solid var(--color-border)' }}
        >
          {/* School logo placeholder */}
          <div
            style={{
              width: '60px',
              height: '60px',
              backgroundColor: 'var(--color-surface-alt)',
              borderRadius: 'var(--radius-inner)',
              border: '1px solid var(--color-border)',
            }}
          />

          <div className="flex-1">
            <h1
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '32px',
                color: 'var(--color-text-primary)',
                marginBottom: '4px',
              }}
            >
              ItemInsight Report
            </h1>
            <p style={{ fontSize: '14px', color: 'var(--color-text-secondary)' }}>
              Generated June 26, 2026
            </p>
          </div>
        </div>

        {/* Test info */}
        <div
          className="grid grid-cols-4 gap-4 p-4 mb-6"
          style={{
            border: '1px solid var(--color-border)',
            borderRadius: 'var(--radius-inner)',
          }}
        >
          <div>
            <p
              style={{
                fontSize: '12px',
                color: 'var(--color-text-secondary)',
                marginBottom: '2px',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              Test Name
            </p>
            <p style={{ fontSize: '14px', fontWeight: 500 }}>Q2 Science Exam</p>
          </div>
          <div>
            <p
              style={{
                fontSize: '12px',
                color: 'var(--color-text-secondary)',
                marginBottom: '2px',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              Section
            </p>
            <p style={{ fontSize: '14px', fontWeight: 500 }}>Grade 10-A</p>
          </div>
          <div>
            <p
              style={{
                fontSize: '12px',
                color: 'var(--color-text-secondary)',
                marginBottom: '2px',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              Items
            </p>
            <p style={{ fontSize: '14px', fontWeight: 500, fontFamily: 'var(--font-data)' }}>
              20
            </p>
          </div>
          <div>
            <p
              style={{
                fontSize: '12px',
                color: 'var(--color-text-secondary)',
                marginBottom: '2px',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              Students
            </p>
            <p style={{ fontSize: '14px', fontWeight: 500, fontFamily: 'var(--font-data)' }}>
              35
            </p>
          </div>
        </div>

        {/* Summary stats */}
        <div
          className="grid grid-cols-4 gap-4 mb-6"
          style={{
            border: '1px solid var(--color-border)',
            borderRadius: 'var(--radius-inner)',
          }}
        >
          <div
            className="p-4"
            style={{ borderRight: '1px solid var(--color-border)' }}
          >
            <p
              style={{
                fontSize: '11px',
                color: 'var(--color-text-secondary)',
                marginBottom: '4px',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              AVG. DIFFICULTY
            </p>
            <div
              style={{
                fontFamily: 'var(--font-data)',
                fontSize: '24px',
                fontWeight: 500,
                color: 'var(--color-text-primary)',
              }}
            >
              0.62
            </div>
            <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>
              Acceptable
            </p>
          </div>
          <div
            className="p-4"
            style={{ borderRight: '1px solid var(--color-border)' }}
          >
            <p
              style={{
                fontSize: '11px',
                color: 'var(--color-text-secondary)',
                marginBottom: '4px',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              AVG. DISCRIMINATION
            </p>
            <div
              style={{
                fontFamily: 'var(--font-data)',
                fontSize: '24px',
                fontWeight: 500,
                color: 'var(--color-text-primary)',
              }}
            >
              0.34
            </div>
            <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>
              Moderate
            </p>
          </div>
          <div
            className="p-4"
            style={{ borderRight: '1px solid var(--color-border)' }}
          >
            <p
              style={{
                fontSize: '11px',
                color: 'var(--color-text-secondary)',
                marginBottom: '4px',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              ITEMS FLAGGED
            </p>
            <div
              style={{
                fontFamily: 'var(--font-data)',
                fontSize: '24px',
                fontWeight: 500,
                color: 'var(--color-text-primary)',
              }}
            >
              6
            </div>
            <p style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>
              Need review
            </p>
          </div>
          <div className="p-4">
            <p
              style={{
                fontSize: '11px',
                color: 'var(--color-text-secondary)',
                marginBottom: '4px',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              TEST QUALITY
            </p>
            <div
              style={{
                fontSize: '18px',
                fontWeight: 600,
                color: 'var(--color-warning)',
              }}
            >
              Acceptable
            </div>
          </div>
        </div>

        {/* Full item results table */}
        <div>
          <h2
            className="mb-3"
            style={{
              fontFamily: 'var(--font-body)',
              fontSize: '15px',
              fontWeight: 600,
              color: 'var(--color-text-primary)',
            }}
          >
            Complete Item Analysis
          </h2>

          <div
            style={{
              border: '1px solid var(--color-border)',
              borderRadius: 'var(--radius-inner)',
              overflow: 'hidden',
            }}
          >
            <table style={{ width: '100%', fontSize: '12px' }}>
              <thead>
                <tr
                  style={{
                    backgroundColor: 'var(--color-surface-alt)',
                    borderBottom: '1px solid var(--color-border)',
                  }}
                >
                  <th
                    style={{
                      padding: '8px 12px',
                      textAlign: 'left',
                      fontSize: '11px',
                      fontWeight: 500,
                      color: 'var(--color-text-secondary)',
                      textTransform: 'uppercase',
                      letterSpacing: '0.05em',
                    }}
                  >
                    Item
                  </th>
                  <th
                    style={{
                      padding: '8px 12px',
                      textAlign: 'left',
                      fontSize: '11px',
                      fontWeight: 500,
                      color: 'var(--color-text-secondary)',
                      textTransform: 'uppercase',
                      letterSpacing: '0.05em',
                    }}
                  >
                    Key
                  </th>
                  <th
                    style={{
                      padding: '8px 12px',
                      textAlign: 'right',
                      fontSize: '11px',
                      fontWeight: 500,
                      color: 'var(--color-text-secondary)',
                      textTransform: 'uppercase',
                      letterSpacing: '0.05em',
                    }}
                  >
                    Difficulty
                  </th>
                  <th
                    style={{
                      padding: '8px 12px',
                      textAlign: 'right',
                      fontSize: '11px',
                      fontWeight: 500,
                      color: 'var(--color-text-secondary)',
                      textTransform: 'uppercase',
                      letterSpacing: '0.05em',
                    }}
                  >
                    Discrimination
                  </th>
                  <th
                    style={{
                      padding: '8px 12px',
                      textAlign: 'left',
                      fontSize: '11px',
                      fontWeight: 500,
                      color: 'var(--color-text-secondary)',
                      textTransform: 'uppercase',
                      letterSpacing: '0.05em',
                    }}
                  >
                    Status
                  </th>
                </tr>
              </thead>
              <tbody>
                {allItems.map((item, index) => (
                  <tr
                    key={item.item}
                    style={{
                      borderBottom:
                        index < allItems.length - 1 ? '1px solid var(--color-border)' : 'none',
                    }}
                  >
                    <td
                      style={{
                        padding: '8px 12px',
                        fontFamily: 'var(--font-data)',
                        fontWeight: 500,
                      }}
                    >
                      {String(item.item).padStart(2, '0')}
                    </td>
                    <td
                      style={{
                        padding: '8px 12px',
                        fontFamily: 'var(--font-data)',
                        fontWeight: 500,
                      }}
                    >
                      {item.key}
                    </td>
                    <td
                      style={{
                        padding: '8px 12px',
                        textAlign: 'right',
                        fontFamily: 'var(--font-data)',
                      }}
                    >
                      {item.difficulty.toFixed(2)}
                    </td>
                    <td
                      style={{
                        padding: '8px 12px',
                        textAlign: 'right',
                        fontFamily: 'var(--font-data)',
                      }}
                    >
                      {item.discrimination.toFixed(2)}
                    </td>
                    <td style={{ padding: '8px 12px', fontSize: '11px' }}>
                      {item.status === 'Good' && '✓ '}
                      {item.status === 'Too Hard' && '⚠ '}
                      {item.status === 'Too Easy' && '⚠ '}
                      {item.status}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer */}
        <div
          className="mt-8 pt-6 text-center"
          style={{ borderTop: '1px solid var(--color-border)' }}
        >
          <p style={{ fontSize: '12px', color: 'var(--color-text-secondary)' }}>
            Generated by <span style={{ fontWeight: 600 }}>ItemInsight</span> · iteminsight.app
          </p>
        </div>
      </div>
    </div>
  );
}
