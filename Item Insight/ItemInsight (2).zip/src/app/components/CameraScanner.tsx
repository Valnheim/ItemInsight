import { useRef, useState, useEffect } from "react";
import { X, Camera, RotateCcw, Check, Loader } from "lucide-react";

interface Props {
  numQuestions: number;
  answerKey: string[];
  onApply: (answers: string[]) => void;
  onClose: () => void;
}

type Stage = "camera" | "captured" | "processing" | "review";

const CHOICES = ["A", "B", "C", "D", "E"];

function parseAnswersFromOCR(text: string, count: number): string[] {
  const answers = new Array(count).fill("");

  // Strategy 1: look for "1 A", "1. A", "1) A", "1: A", "Q1 A" patterns
  const lines = text.split("\n");
  for (const line of lines) {
    const m = line.match(/(?:Q|Item|No\.?)?\s*(\d{1,3})[.):\s]+\s*([ABCDE])\b/i);
    if (m) {
      const idx = parseInt(m[1]) - 1;
      if (idx >= 0 && idx < count) answers[idx] = m[2].toUpperCase();
    }
  }

  // Strategy 2: if most are empty, look for a sequence of bare letters (A B C D A…)
  const filled = answers.filter((a) => a !== "").length;
  if (filled < count * 0.4) {
    const bare = text.match(/\b([ABCDE])\b/gi) ?? [];
    bare.slice(0, count).forEach((ch, i) => {
      if (answers[i] === "") answers[i] = ch.toUpperCase();
    });
  }

  return answers;
}

export default function CameraScanner({ numQuestions, answerKey, onApply, onClose }: Props) {
  const videoRef   = useRef<HTMLVideoElement>(null);
  const canvasRef  = useRef<HTMLCanvasElement>(null);
  const streamRef  = useRef<MediaStream | null>(null);

  const [stage, setStage]                 = useState<Stage>("camera");
  const [capturedDataUrl, setCaptured]    = useState<string | null>(null);
  const [ocrProgress, setOcrProgress]     = useState(0);
  const [ocrStatus, setOcrStatus]         = useState("");
  const [answers, setAnswers]             = useState<string[]>(new Array(numQuestions).fill(""));
  const [camError, setCamError]           = useState<string | null>(null);

  // Start camera on mount
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: "environment" }, width: { ideal: 1920 }, height: { ideal: 1080 } },
        });
        if (cancelled) { stream.getTracks().forEach((t) => t.stop()); return; }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }
      } catch {
        if (!cancelled) setCamError("Camera access was denied. Please allow camera permissions in your browser settings and try again.");
      }
    })();
    return () => {
      cancelled = true;
      streamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  const stopCamera = () => streamRef.current?.getTracks().forEach((t) => t.stop());

  const capture = () => {
    const video  = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    canvas.width  = video.videoWidth  || 1280;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.92);
    setCaptured(dataUrl);
    stopCamera();
    setStage("captured");
  };

  const retake = () => {
    setCaptured(null);
    setStage("camera");
    // Restart camera
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" } } })
      .then((stream) => {
        streamRef.current = stream;
        if (videoRef.current) { videoRef.current.srcObject = stream; videoRef.current.play(); }
      })
      .catch(() => setCamError("Could not restart camera."));
  };

  const runOCR = async () => {
    if (!capturedDataUrl) return;
    setStage("processing");
    setOcrProgress(0);
    setOcrStatus("Loading OCR engine…");

    try {
      const { createWorker } = await import("tesseract.js");
      const worker = await createWorker("eng", 1, {
        logger: (m: { status: string; progress: number }) => {
          if (m.status === "loading tesseract core") setOcrStatus("Loading OCR engine…");
          if (m.status === "initializing tesseract") setOcrStatus("Initializing…");
          if (m.status === "loading language traineddata") setOcrStatus("Loading language data…");
          if (m.status === "recognizing text") {
            setOcrProgress(Math.round(m.progress * 100));
            setOcrStatus("Recognizing text…");
          }
        },
      });

      const { data: { text } } = await worker.recognize(capturedDataUrl);
      await worker.terminate();

      const parsed = parseAnswersFromOCR(text, numQuestions);
      setAnswers(parsed);
      setStage("review");
    } catch {
      setOcrStatus("OCR failed. Try a clearer, better-lit photo.");
      setStage("captured");
    }
  };

  const setAnswer = (i: number, val: string) => {
    const next = [...answers];
    next[i] = val;
    setAnswers(next);
  };

  const handleApply = () => {
    onApply(answers);
    onClose();
  };

  const hasKey = answerKey.length === numQuestions && answerKey.some((k) => k !== "");

  const filledCount = answers.filter((a) => a !== "").length;
  const correctCount = hasKey
    ? answers.filter((a, i) => a !== "" && a === answerKey[i]).length
    : null;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 200,
        backgroundColor: "rgba(26, 24, 16, 0.92)",
        display: "flex",
        flexDirection: "column",
        fontFamily: "var(--font-body)",
      }}
    >
      {/* Header bar */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "14px 20px",
          backgroundColor: "var(--color-primary)",
          flexShrink: 0,
        }}
      >
        <div>
          <p style={{ fontFamily: "var(--font-display)", fontSize: "18px", fontWeight: 700, color: "white", margin: 0 }}>
            Scan Student Answer Sheet
          </p>
          <p style={{ fontSize: "12px", color: "rgba(255,255,255,0.7)", margin: 0 }}>
            {stage === "camera" && "Position the sheet clearly in frame, then capture"}
            {stage === "captured" && "Review the photo, then extract answers"}
            {stage === "processing" && "Processing with OCR — please wait"}
            {stage === "review" && `${filledCount} of ${numQuestions} answers extracted — review and confirm`}
          </p>
        </div>
        <button onClick={() => { stopCamera(); onClose(); }}
          style={{ background: "none", border: "none", color: "rgba(255,255,255,0.8)", cursor: "pointer", padding: "6px", borderRadius: "4px" }}>
          <X size={22} />
        </button>
      </div>

      {/* Body */}
      <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>

        {/* Camera error */}
        {camError && (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "white", textAlign: "center", padding: "32px" }}>
            <Camera size={48} style={{ opacity: 0.4, marginBottom: "16px" }} />
            <p style={{ fontSize: "16px", fontWeight: 600, marginBottom: "8px" }}>Camera Unavailable</p>
            <p style={{ fontSize: "14px", opacity: 0.7, maxWidth: "320px" }}>{camError}</p>
          </div>
        )}

        {/* Camera live view */}
        {!camError && (stage === "camera") && (
          <div style={{ flex: 1, position: "relative", display: "flex", alignItems: "center", justifyContent: "center", backgroundColor: "#000" }}>
            <video ref={videoRef} autoPlay playsInline muted
              style={{ maxWidth: "100%", maxHeight: "100%", objectFit: "contain" }} />
            {/* Framing guide */}
            <div style={{ position: "absolute", inset: "10%", border: "2px dashed rgba(255,255,255,0.4)", borderRadius: "8px", pointerEvents: "none" }} />
            <p style={{ position: "absolute", bottom: "calc(10% + 12px)", left: "50%", transform: "translateX(-50%)", color: "rgba(255,255,255,0.6)", fontSize: "12px", whiteSpace: "nowrap" }}>
              Keep the sheet flat and well-lit
            </p>
            {/* Capture button */}
            <button
              onClick={capture}
              style={{
                position: "absolute",
                bottom: "32px",
                left: "50%",
                transform: "translateX(-50%)",
                width: "68px",
                height: "68px",
                borderRadius: "50%",
                backgroundColor: "white",
                border: "4px solid rgba(255,255,255,0.5)",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                boxShadow: "0 4px 20px rgba(0,0,0,0.4)",
              }}
            >
              <Camera size={28} color="var(--color-primary)" />
            </button>
          </div>
        )}

        {/* Captured image view */}
        {(stage === "captured" || stage === "processing") && capturedDataUrl && (
          <div style={{ flex: 1, position: "relative", display: "flex", alignItems: "center", justifyContent: "center", backgroundColor: "#000" }}>
            <img src={capturedDataUrl} alt="Captured" style={{ maxWidth: "100%", maxHeight: "100%", objectFit: "contain" }} />
            {/* Processing overlay */}
            {stage === "processing" && (
              <div style={{
                position: "absolute", inset: 0,
                backgroundColor: "rgba(26, 24, 16, 0.75)",
                display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
                color: "white",
              }}>
                <Loader size={36} style={{ marginBottom: "16px", animation: "spin 1s linear infinite" }} />
                <p style={{ fontSize: "16px", fontWeight: 600, marginBottom: "8px" }}>{ocrStatus}</p>
                {ocrProgress > 0 && (
                  <div style={{ width: "200px", height: "6px", backgroundColor: "rgba(255,255,255,0.2)", borderRadius: "3px", overflow: "hidden" }}>
                    <div style={{ height: "100%", width: `${ocrProgress}%`, backgroundColor: "var(--color-success)", transition: "width 0.3s" }} />
                  </div>
                )}
                <p style={{ fontSize: "12px", opacity: 0.6, marginTop: "8px" }}>{ocrProgress}%</p>
              </div>
            )}
            {/* Captured action buttons */}
            {stage === "captured" && (
              <div style={{ position: "absolute", bottom: "24px", left: "50%", transform: "translateX(-50%)", display: "flex", gap: "12px" }}>
                <button onClick={retake} style={ghostBtn}>
                  <RotateCcw size={16} /> Retake
                </button>
                <button onClick={runOCR} style={primaryBtn}>
                  Extract Answers →
                </button>
              </div>
            )}
          </div>
        )}

        {/* Review panel */}
        {stage === "review" && (
          <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
            {/* Left — captured image thumbnail */}
            <div style={{ width: "40%", backgroundColor: "#000", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              {capturedDataUrl && (
                <img src={capturedDataUrl} alt="Captured" style={{ maxWidth: "100%", maxHeight: "100%", objectFit: "contain", opacity: 0.9 }} />
              )}
            </div>

            {/* Right — answer review grid */}
            <div style={{ flex: 1, backgroundColor: "var(--color-surface)", display: "flex", flexDirection: "column", overflow: "hidden" }}>
              {/* Summary bar */}
              <div style={{ padding: "14px 20px", borderBottom: "1px solid var(--color-border)", backgroundColor: "var(--color-surface-alt)", display: "flex", gap: "24px", alignItems: "center", flexShrink: 0 }}>
                <span style={{ fontSize: "13px", color: "var(--color-text-secondary)" }}>
                  Extracted: <strong style={{ color: "var(--color-text-primary)", fontFamily: "var(--font-data)" }}>{filledCount}/{numQuestions}</strong>
                </span>
                {correctCount !== null && (
                  <>
                    <span style={{ fontSize: "13px", color: "var(--color-success)", fontWeight: 600 }}>
                      ✓ {correctCount} correct
                    </span>
                    <span style={{ fontSize: "13px", color: "var(--color-danger)", fontWeight: 600 }}>
                      ✗ {filledCount - correctCount} wrong
                    </span>
                  </>
                )}
                <span style={{ fontSize: "11px", color: "var(--color-text-secondary)", marginLeft: "auto" }}>
                  Review and edit if needed
                </span>
              </div>

              {/* Answer grid */}
              <div style={{ flex: 1, overflowY: "auto", padding: "12px 16px" }}>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "6px" }}>
                  {answers.map((ans, i) => {
                    const keyAns  = hasKey ? answerKey[i] ?? "" : "";
                    const isRight = ans !== "" && ans === keyAns;
                    const isWrong = ans !== "" && keyAns !== "" && ans !== keyAns;
                    const isEmpty = ans === "";

                    let borderColor = "var(--color-border)";
                    let bgColor     = "var(--color-surface-alt)";
                    if (isRight) { borderColor = "var(--color-success)"; bgColor = "var(--color-success-soft)"; }
                    if (isWrong) { borderColor = "var(--color-danger)";  bgColor = "var(--color-danger-soft)";  }

                    return (
                      <div
                        key={i}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "8px",
                          padding: "6px 10px",
                          border: `1px solid ${borderColor}`,
                          borderRadius: "var(--radius-inner)",
                          backgroundColor: bgColor,
                          transition: "all 0.1s",
                        }}
                      >
                        <span style={{ fontFamily: "var(--font-data)", fontSize: "12px", fontWeight: 600, color: "var(--color-text-secondary)", minWidth: "24px" }}>
                          {String(i + 1).padStart(2, "0")}
                        </span>
                        <select
                          value={ans}
                          onChange={(e) => setAnswer(i, e.target.value)}
                          style={{
                            flex: 1,
                            border: "none",
                            background: "transparent",
                            fontSize: "15px",
                            fontFamily: "var(--font-data)",
                            fontWeight: 700,
                            color: isEmpty ? "var(--color-text-secondary)" : isRight ? "var(--color-success)" : isWrong ? "var(--color-danger)" : "var(--color-text-primary)",
                            cursor: "pointer",
                            outline: "none",
                          }}
                        >
                          <option value="">—</option>
                          {CHOICES.map((c) => <option key={c} value={c}>{c}</option>)}
                        </select>
                        {hasKey && keyAns && (
                          <span style={{ fontSize: "11px", color: "var(--color-text-secondary)", fontFamily: "var(--font-data)" }}>
                            Key: {keyAns}
                          </span>
                        )}
                        {isRight && <Check size={14} color="var(--color-success)" />}
                        {isWrong && <X     size={14} color="var(--color-danger)"  />}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Footer actions */}
              <div style={{ padding: "16px 20px", borderTop: "1px solid var(--color-border)", display: "flex", gap: "10px", justifyContent: "flex-end", flexShrink: 0 }}>
                <button onClick={retake} style={ghostBtn}>
                  <RotateCcw size={14} /> Rescan
                </button>
                <button onClick={handleApply} style={primaryBtn}>
                  <Check size={14} /> Apply to Tally
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Hidden canvas for frame capture */}
      <canvas ref={canvasRef} style={{ display: "none" }} />

      <style>{`
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}

const ghostBtn: React.CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: "6px",
  padding: "9px 16px",
  backgroundColor: "rgba(255,255,255,0.12)",
  color: "white",
  border: "1px solid rgba(255,255,255,0.25)",
  borderRadius: "4px",
  cursor: "pointer",
  fontSize: "13px",
  fontWeight: 500,
};

const primaryBtn: React.CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: "6px",
  padding: "9px 20px",
  backgroundColor: "var(--color-primary)",
  color: "white",
  border: "none",
  borderRadius: "4px",
  cursor: "pointer",
  fontSize: "13px",
  fontWeight: 600,
};
