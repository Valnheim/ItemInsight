interface HealthBarProps {
  value: number;
  size?: 'small' | 'large';
}

export function HealthBar({ value, size = 'small' }: HealthBarProps) {
  const width = size === 'small' ? 120 : '100%';
  const height = size === 'small' ? 8 : 16;
  const thumbSize = size === 'small' ? 12 : 20;

  // Clamp value between 0 and 1
  const clampedValue = Math.max(0, Math.min(1, value));
  const position = clampedValue * 100;

  return (
    <div 
      className="relative flex items-center" 
      style={{ 
        width,
        height: thumbSize,
      }}
    >
      {/* Background track with three zones */}
      <div 
        className="absolute inset-y-0 left-0 right-0 flex overflow-hidden"
        style={{
          height,
          borderRadius: 999,
          top: '50%',
          transform: 'translateY(-50%)',
        }}
      >
        {/* Red zone (0-0.20) */}
        <div 
          className="flex-shrink-0" 
          style={{ 
            width: '20%',
            backgroundColor: 'var(--color-danger)',
          }}
        />
        
        {/* Green zone (0.20-0.80) */}
        <div 
          className="flex-shrink-0" 
          style={{ 
            width: '60%',
            backgroundColor: 'var(--color-success)',
          }}
        />
        
        {/* Red zone (0.80-1.00) */}
        <div 
          className="flex-shrink-0" 
          style={{ 
            width: '20%',
            backgroundColor: 'var(--color-danger)',
          }}
        />
      </div>

      {/* Marker/thumb */}
      <div
        className="absolute z-10"
        style={{
          left: `${position}%`,
          width: thumbSize,
          height: thumbSize,
          transform: 'translateX(-50%)',
          backgroundColor: 'var(--color-surface)',
          border: '2px solid var(--color-text-primary)',
          borderRadius: '50%',
          boxShadow: '0 1px 4px rgba(0, 0, 0, 0.15)',
        }}
      />
    </div>
  );
}
