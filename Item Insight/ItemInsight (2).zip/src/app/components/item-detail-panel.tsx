import { X, AlertTriangle, CheckCircle } from 'lucide-react';
import { HealthBar } from './health-bar';

interface ItemDetailPanelProps {
  isOpen: boolean;
  onClose: () => void;
  itemNumber: number;
}

export function ItemDetailPanel({ isOpen, onClose, itemNumber }: ItemDetailPanelProps) {
  if (!isOpen) return null;

  // Sample data for Item 02
  const itemData = {
    correctAnswer: 'C',
    difficulty: 0.23,
    discrimination: 0.18,
    distractors: [
      { option: 'A', pctAll: 31, pctUpper: 8, pctLower: 42, status: 'working' },
      { option: 'B', pctAll: 18, pctUpper: 10, pctLower: 22, status: 'working' },
      { option: 'C', pctAll: 23, pctUpper: 48, pctLower: 8, status: 'correct' },
      { option: 'D', pctAll: 28, pctUpper: 34, pctLower: 28, status: 'ineffective' },
    ],
  };

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-black/40 z-40"
        onClick={onClose}
        style={{ backdropFilter: 'blur(2px)' }}
      />

      {/* Panel */}
      <div
        className="fixed top-0 right-0 bottom-0 z-50 overflow-y-auto"
        style={{
          width: '480px',
          backgroundColor: 'var(--color-surface)',
          boxShadow: 'var(--shadow-elevated)',
          fontFamily: 'var(--font-body)',
          animation: 'slideIn 0.2s ease-out',
        }}
      >
        <style>
          {`
            @keyframes slideIn {
              from {
                transform: translateX(100%);
              }
              to {
                transform: translateX(0);
              }
            }
          `}
        </style>

        {/* Header */}
        <div
          className="sticky top-0 flex items-center justify-between p-6"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderBottom: '1px solid var(--color-border)',
          }}
        >
          <div>
            <p
              style={{
                fontSize: '12px',
                fontWeight: 500,
                color: 'var(--color-text-secondary)',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
                marginBottom: '4px',
              }}
            >
              ITEM {String(itemNumber).padStart(2, '0')}
            </p>
            <div className="flex items-center gap-3">
              <span style={{ fontSize: '14px', color: 'var(--color-text-primary)' }}>
                Correct Answer: <span style={{ fontFamily: 'var(--font-data)' }}>
                  {itemData.correctAnswer}
                </span>
              </span>
              <span
                style={{
                  fontSize: '14px',
                  color: 'var(--color-text-secondary)',
                  fontFamily: 'var(--font-data)',
                }}
              >
                p = {itemData.difficulty.toFixed(2)}
              </span>
              <span
                style={{
                  fontSize: '14px',
                  color: 'var(--color-text-secondary)',
                  fontFamily: 'var(--font-data)',
                }}
              >
                D = {itemData.discrimination.toFixed(2)}
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="transition-colors"
            style={{
              background: 'none',
              border: 'none',
              color: 'var(--color-text-secondary)',
              cursor: 'pointer',
              padding: '4px',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.color = 'var(--color-text-primary)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.color = 'var(--color-text-secondary)';
            }}
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Flags */}
          <div className="flex gap-2">
            <span
              style={{
                padding: '4px 12px',
                borderRadius: 'var(--radius-pill)',
                backgroundColor: 'var(--color-danger-soft)',
                color: 'var(--color-danger)',
                fontSize: '12px',
                fontWeight: 500,
              }}
            >
              Too Hard
            </span>
            <span
              style={{
                padding: '4px 12px',
                borderRadius: 'var(--radius-pill)',
                backgroundColor: 'var(--color-danger-soft)',
                color: 'var(--color-danger)',
                fontSize: '12px',
                fontWeight: 500,
              }}
            >
              Poor Discriminator
            </span>
          </div>

          {/* Difficulty Index */}
          <div>
            <h3
              className="mb-3"
              style={{
                fontSize: '15px',
                fontWeight: 600,
                color: 'var(--color-text-primary)',
              }}
            >
              Difficulty Index
            </h3>
            <HealthBar value={itemData.difficulty} size="large" />
            <div className="flex justify-between mt-2">
              <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>
                Too Hard
              </span>
              <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>
                Acceptable
              </span>
              <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>
                Too Easy
              </span>
            </div>
          </div>

          {/* Discrimination Index */}
          <div>
            <h3
              className="mb-3"
              style={{
                fontSize: '15px',
                fontWeight: 600,
                color: 'var(--color-text-primary)',
              }}
            >
              Discrimination Index
            </h3>
            <div className="relative" style={{ height: '16px' }}>
              {/* Bar from -1 to +1 */}
              <div
                className="absolute inset-y-0 left-0 right-0 flex"
                style={{
                  borderRadius: '999px',
                  overflow: 'hidden',
                }}
              >
                <div
                  style={{
                    width: '50%',
                    background: 'linear-gradient(to right, var(--color-danger), var(--color-warning))',
                  }}
                />
                <div
                  style={{
                    width: '50%',
                    background: 'linear-gradient(to right, var(--color-warning), var(--color-success))',
                  }}
                />
              </div>
              {/* Center line */}
              <div
                className="absolute top-0 bottom-0"
                style={{
                  left: '50%',
                  width: '2px',
                  backgroundColor: 'var(--color-text-primary)',
                  transform: 'translateX(-50%)',
                }}
              />
              {/* Marker */}
              <div
                className="absolute"
                style={{
                  left: `${((itemData.discrimination + 1) / 2) * 100}%`,
                  width: '16px',
                  height: '16px',
                  transform: 'translateX(-50%)',
                  backgroundColor: 'var(--color-surface)',
                  border: '2px solid var(--color-text-primary)',
                  borderRadius: '50%',
                  boxShadow: '0 1px 4px rgba(0, 0, 0, 0.15)',
                }}
              />
            </div>
            <div className="flex justify-between mt-2">
              <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>
                -1.0
              </span>
              <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>
                0
              </span>
              <span style={{ fontSize: '11px', color: 'var(--color-text-secondary)' }}>
                +1.0
              </span>
            </div>
          </div>

          {/* Distractor Analysis */}
          <div>
            <h3
              className="mb-3"
              style={{
                fontSize: '15px',
                fontWeight: 600,
                color: 'var(--color-text-primary)',
              }}
            >
              Distractor Analysis
            </h3>
            <div
              style={{
                border: '1px solid var(--color-border)',
                borderRadius: 'var(--radius-inner)',
                overflow: 'hidden',
              }}
            >
              <table style={{ width: '100%', fontSize: '12px' }}>
                <thead>
                  <tr
                    style={{
                      backgroundColor: 'var(--color-surface-alt)',
                      borderBottom: '1px solid var(--color-border)',
                    }}
                  >
                    <th
                      style={{
                        padding: '8px',
                        textAlign: 'left',
                        fontWeight: 500,
                        color: 'var(--color-text-secondary)',
                      }}
                    >
                      Option
                    </th>
                    <th
                      style={{
                        padding: '8px',
                        textAlign: 'right',
                        fontWeight: 500,
                        color: 'var(--color-text-secondary)',
                      }}
                    >
                      % All
                    </th>
                    <th
                      style={{
                        padding: '8px',
                        textAlign: 'right',
                        fontWeight: 500,
                        color: 'var(--color-text-secondary)',
                      }}
                    >
                      % Upper
                    </th>
                    <th
                      style={{
                        padding: '8px',
                        textAlign: 'right',
                        fontWeight: 500,
                        color: 'var(--color-text-secondary)',
                      }}
                    >
                      % Lower
                    </th>
                    <th
                      style={{
                        padding: '8px',
                        textAlign: 'left',
                        fontWeight: 500,
                        color: 'var(--color-text-secondary)',
                      }}
                    >
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {itemData.distractors.map((distractor, index) => (
                    <tr
                      key={distractor.option}
                      style={{
                        backgroundColor:
                          distractor.status === 'correct'
                            ? 'var(--color-primary-soft)'
                            : distractor.status === 'ineffective'
                            ? 'var(--color-warning-soft)'
                            : 'transparent',
                        borderBottom:
                          index < itemData.distractors.length - 1
                            ? '1px solid var(--color-border)'
                            : 'none',
                      }}
                    >
                      <td
                        style={{
                          padding: '8px',
                          fontFamily: 'var(--font-data)',
                          fontWeight: 500,
                        }}
                      >
                        {distractor.option}
                        {distractor.status === 'correct' && ' ✓'}
                      </td>
                      <td
                        style={{
                          padding: '8px',
                          textAlign: 'right',
                          fontFamily: 'var(--font-data)',
                        }}
                      >
                        {distractor.pctAll}%
                      </td>
                      <td
                        style={{
                          padding: '8px',
                          textAlign: 'right',
                          fontFamily: 'var(--font-data)',
                        }}
                      >
                        {distractor.pctUpper}%
                      </td>
                      <td
                        style={{
                          padding: '8px',
                          textAlign: 'right',
                          fontFamily: 'var(--font-data)',
                        }}
                      >
                        {distractor.pctLower}%
                      </td>
                      <td style={{ padding: '8px', fontSize: '11px' }}>
                        {distractor.status === 'correct' ? (
                          <span style={{ color: 'var(--color-primary)' }}>
                            ← Correct answer
                          </span>
                        ) : distractor.status === 'working' ? (
                          <span style={{ color: 'var(--color-success)' }}>✓ Working</span>
                        ) : (
                          <span style={{ color: 'var(--color-warning)' }}>⚠ Ineffective</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Suggestions */}
          <div
            style={{
              backgroundColor: 'var(--color-surface-alt)',
              borderLeft: '3px solid var(--color-warning)',
              borderRadius: 'var(--radius-inner)',
              padding: '16px',
            }}
          >
            <h3
              className="mb-2 flex items-center gap-2"
              style={{
                fontSize: '15px',
                fontWeight: 600,
                color: 'var(--color-text-primary)',
              }}
            >
              <AlertTriangle size={16} style={{ color: 'var(--color-warning)' }} />
              Suggestions
            </h3>
            <ul className="space-y-3">
              <li
                style={{
                  fontSize: '13px',
                  color: 'var(--color-text-primary)',
                  lineHeight: 1.5,
                }}
              >
                This item may be too difficult for your class. Consider revising the stem for
                clarity or reviewing whether the content was adequately taught.
              </li>
              <li
                style={{
                  fontSize: '13px',
                  color: 'var(--color-text-primary)',
                  lineHeight: 1.5,
                }}
              >
                Distractor D is ineffective — too many high-scorers chose it. Revise it to be a
                more plausible but clearly wrong answer.
              </li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
}
