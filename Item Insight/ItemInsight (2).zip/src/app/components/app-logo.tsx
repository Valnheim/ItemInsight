interface AppLogoProps {
  size?: 'small' | 'large';
}

export function AppLogo({ size = 'small' }: AppLogoProps) {
  const iconSize = size === 'small' ? 24 : 32;
  const fontSize = size === 'small' ? '16px' : '20px';

  return (
    <div className="flex items-center gap-2">
      {/* Icon: circle divided into thirds like a pie chart */}
      <svg
        width={iconSize}
        height={iconSize}
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Background circle */}
        <circle cx="12" cy="12" r="10" fill="var(--color-primary)" />
        
        {/* Three uneven slices */}
        <path
          d="M 12 12 L 12 2 A 10 10 0 0 1 18.66 6.34 Z"
          fill="var(--color-success)"
        />
        <path
          d="M 12 12 L 18.66 6.34 A 10 10 0 0 1 18.66 17.66 Z"
          fill="var(--color-warning)"
        />
        <path
          d="M 12 12 L 18.66 17.66 A 10 10 0 0 1 12 2 Z"
          fill="var(--color-danger)"
          fillOpacity="0.8"
        />
      </svg>
      
      <span
        style={{
          fontFamily: 'var(--font-body)',
          fontSize,
          fontWeight: 600,
          color: 'var(--color-text-primary)',
        }}
      >
        ItemInsight
      </span>
    </div>
  );
}
