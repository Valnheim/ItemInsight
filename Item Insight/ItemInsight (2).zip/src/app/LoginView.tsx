import { useState, useEffect, useRef } from "react";
import { Mail, ShieldCheck, LogIn, ArrowRight, RefreshCw, Copy, CheckCheck, UserRound, UserPlus } from "lucide-react";
import * as OTPAuth from "otpauth";
import { QRCodeSVG } from "qrcode.react";
import { AppLogo } from "./components/app-logo";

interface LoginViewProps {
  onLogin: (email: string, isGuest?: boolean) => void;
}

type Mode = "login" | "signup";
type Phase = "email" | "setup" | "verify";

const STORAGE_KEY = "iteminsight_totp_secrets";

function getSecrets(): Record<string, string> {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
  } catch {
    return {};
  }
}

function saveSecret(email: string, secret: string) {
  const all = getSecrets();
  all[email] = secret;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

function accountExists(email: string): boolean {
  return email in getSecrets();
}

function generateSecret(): string {
  const bytes = new Uint8Array(20);
  crypto.getRandomValues(bytes);
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let result = "";
  let bits = 0;
  let value = 0;
  for (const byte of bytes) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      result += chars[(value >>> (bits - 5)) & 0x1f];
      bits -= 5;
    }
  }
  if (bits > 0) result += chars[(value << (5 - bits)) & 0x1f];
  return result;
}

function verifyTOTP(secret: string, token: string): boolean {
  try {
    const totp = new OTPAuth.TOTP({
      secret: OTPAuth.Secret.fromBase32(secret),
      algorithm: "SHA1",
      digits: 6,
      period: 30,
    });
    return totp.validate({ token, window: 1 }) !== null;
  } catch {
    return false;
  }
}

function getTOTPUri(email: string, secret: string): string {
  const totp = new OTPAuth.TOTP({
    issuer: "ItemInsight",
    label: email,
    secret: OTPAuth.Secret.fromBase32(secret),
    algorithm: "SHA1",
    digits: 6,
    period: 30,
  });
  return totp.toString();
}

// ── Shared card wrapper ────────────────────────────────────────────────────
function Card({ children }: { children: React.ReactNode }) {
  return (
    <div style={{
      minHeight: "100vh",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: "var(--color-bg)",
      padding: "24px",
    }}>
      <div style={{
        width: "100%",
        maxWidth: "420px",
        backgroundColor: "var(--color-surface)",
        borderRadius: "var(--radius-card)",
        border: "1px solid var(--color-border)",
        padding: "40px 36px",
        boxShadow: "var(--shadow-elevated)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
      }}>
        <div style={{ marginBottom: "28px", transform: "scale(1.1)" }}>
          <AppLogo size="large" />
        </div>
        {children}
      </div>
    </div>
  );
}

// ── Mode toggle tabs ───────────────────────────────────────────────────────
function ModeTabs({ mode, onChange }: { mode: Mode; onChange: (m: Mode) => void }) {
  return (
    <div style={{
      display: "flex",
      width: "100%",
      backgroundColor: "var(--color-bg)",
      borderRadius: "10px",
      padding: "4px",
      marginBottom: "28px",
      gap: "2px",
    }}>
      {(["login", "signup"] as Mode[]).map((m) => {
        const active = mode === m;
        return (
          <button
            key={m}
            onClick={() => onChange(m)}
            style={{
              flex: 1,
              padding: "9px",
              border: "none",
              borderRadius: "7px",
              fontSize: "14px",
              fontWeight: active ? 600 : 400,
              cursor: "pointer",
              transition: "all 0.18s",
              backgroundColor: active ? "var(--color-surface)" : "transparent",
              color: active ? "var(--color-primary)" : "var(--color-text-secondary)",
              boxShadow: active ? "0 1px 4px rgba(0,0,0,0.08)" : "none",
            }}
          >
            {m === "login" ? "Log In" : "Sign Up"}
          </button>
        );
      })}
    </div>
  );
}

export default function LoginView({ onLogin }: LoginViewProps) {
  const [mode, setMode] = useState<Mode>("login");
  const [phase, setPhase] = useState<Phase>("email");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [secret, setSecret] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [countdown, setCountdown] = useState(30);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Reset to email phase when mode tab changes
  const handleModeChange = (m: Mode) => {
    setMode(m);
    setPhase("email");
    setEmail("");
    setCode("");
    setError("");
  };

  // Live countdown
  useEffect(() => {
    if (phase === "verify" || phase === "setup") {
      const tick = () => setCountdown(30 - (Math.floor(Date.now() / 1000) % 30));
      tick();
      intervalRef.current = setInterval(tick, 1000);
      return () => clearInterval(intervalRef.current!);
    }
  }, [phase]);

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!email) return;

    if (mode === "login") {
      if (!accountExists(email)) {
        setError("No account found for this email. Please sign up first.");
        return;
      }
      setSecret(getSecrets()[email]);
      setPhase("verify");
    } else {
      // signup
      if (accountExists(email)) {
        setError("An account already exists for this email. Please log in instead.");
        return;
      }
      setSecret(generateSecret());
      setPhase("setup");
    }
    setCode("");
  };

  const handleSetupConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (code.length !== 6) {
      setError("Please enter the 6-digit code from your authenticator app.");
      return;
    }
    setIsLoading(true);
    setTimeout(() => {
      if (verifyTOTP(secret, code)) {
        saveSecret(email, secret);
        onLogin(email);
      } else {
        setError("Incorrect code. Make sure you scanned the QR code and try again.");
        setCode("");
      }
      setIsLoading(false);
    }, 400);
  };

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (code.length !== 6) {
      setError("Enter the 6-digit code shown in your authenticator app.");
      return;
    }
    setIsLoading(true);
    setTimeout(() => {
      if (verifyTOTP(secret, code)) {
        onLogin(email);
      } else {
        setError("Incorrect code. Codes refresh every 30 seconds — try again.");
        setCode("");
      }
      setIsLoading(false);
    }, 400);
  };

  const handleCopySecret = () => {
    navigator.clipboard.writeText(secret).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const formatSecret = (s: string) => s.match(/.{1,4}/g)?.join(" ") ?? s;

  // Shared code input block
  const CodeInput = ({ onSubmit, submitLabel }: { onSubmit: (e: React.FormEvent) => void; submitLabel: string }) => (
    <form onSubmit={onSubmit} style={{ width: "100%", display: "flex", flexDirection: "column", gap: "12px" }}>
      <div>
        <label style={{ display: "block", fontSize: "13px", fontWeight: 600, color: "var(--color-text-primary)", marginBottom: "6px" }}>
          6-Digit Code
        </label>
        <div style={{ position: "relative" }}>
          <input
            type="text"
            inputMode="numeric"
            pattern="[0-9]*"
            maxLength={6}
            autoFocus
            placeholder="000000"
            value={code}
            onChange={(e) => { setCode(e.target.value.replace(/\D/g, "").slice(0, 6)); setError(""); }}
            style={{
              width: "100%",
              padding: "12px",
              borderRadius: "var(--radius-input)",
              border: `1px solid ${error ? "#c0392b" : "var(--color-border)"}`,
              backgroundColor: "white",
              fontSize: "28px",
              fontFamily: "var(--font-mono)",
              letterSpacing: "0.35em",
              textAlign: "center",
              outline: "none",
              transition: "border-color 0.2s",
              boxSizing: "border-box",
            }}
            onFocus={(e) => (e.target.style.borderColor = "var(--color-primary)")}
            onBlur={(e) => (e.target.style.borderColor = error ? "#c0392b" : "var(--color-border)")}
          />
          <div style={{ position: "absolute", right: "12px", top: "50%", transform: "translateY(-50%)", display: "flex", alignItems: "center", gap: "4px" }}>
            <RefreshCw size={12} style={{ color: countdown <= 5 ? "#e67e22" : "var(--color-text-secondary)", opacity: 0.7 }} />
            <span style={{ fontSize: "11px", color: countdown <= 5 ? "#e67e22" : "var(--color-text-secondary)", fontFamily: "var(--font-mono)", fontWeight: countdown <= 5 ? 700 : 400 }}>
              {countdown}s
            </span>
          </div>
        </div>
        {error && <p style={{ fontSize: "12px", color: "#c0392b", marginTop: "6px" }}>{error}</p>}
      </div>

      <div style={{ height: "3px", borderRadius: "2px", backgroundColor: "var(--color-border)", overflow: "hidden" }}>
        <div style={{
          height: "100%",
          width: `${(countdown / 30) * 100}%`,
          backgroundColor: countdown <= 5 ? "#e67e22" : "var(--color-primary)",
          transition: "width 1s linear, background-color 0.3s",
        }} />
      </div>

      <button
        type="submit"
        disabled={isLoading || code.length !== 6}
        style={{
          width: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: "8px",
          backgroundColor: "var(--color-primary)",
          color: "white",
          border: "none",
          borderRadius: "var(--radius-button)",
          padding: "12px",
          fontSize: "15px",
          fontWeight: 600,
          cursor: isLoading || code.length !== 6 ? "not-allowed" : "pointer",
          opacity: isLoading || code.length !== 6 ? 0.6 : 1,
          transition: "all 0.2s",
        }}
      >
        {isLoading ? "Verifying..." : submitLabel}
      </button>

      <button
        type="button"
        onClick={() => { setPhase("email"); setCode(""); setError(""); }}
        style={{ background: "none", border: "none", color: "var(--color-text-secondary)", fontSize: "13px", cursor: "pointer", padding: "4px" }}
      >
        ← Back
      </button>
    </form>
  );

  // ── Phase: Email entry ─────────────────────────────────────────────────
  if (phase === "email") {
    return (
      <Card>
        <ModeTabs mode={mode} onChange={handleModeChange} />

        <h1 style={{ fontFamily: "var(--font-display)", fontSize: "24px", color: "var(--color-primary)", marginBottom: "6px", textAlign: "center" }}>
          {mode === "login" ? "Welcome Back" : "Create Account"}
        </h1>
        <p style={{ color: "var(--color-text-secondary)", fontSize: "13px", marginBottom: "24px", textAlign: "center", lineHeight: 1.6 }}>
          {mode === "login"
            ? "Enter your email to continue with your authenticator code."
            : "Enter your email to set up Google Authenticator — no password needed."}
        </p>

        <form onSubmit={handleEmailSubmit} style={{ width: "100%", display: "flex", flexDirection: "column", gap: "14px" }}>
          <div>
            <label style={{ display: "block", fontSize: "13px", fontWeight: 600, color: "var(--color-text-primary)", marginBottom: "6px" }}>
              Email Address
            </label>
            <div style={{ position: "relative" }}>
              <Mail size={16} style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", color: "var(--color-text-secondary)" }} />
              <input
                type="email"
                autoFocus
                placeholder="teacher@school.edu.ph"
                value={email}
                onChange={(e) => { setEmail(e.target.value); setError(""); }}
                required
                style={{
                  width: "100%",
                  padding: "10px 12px 10px 38px",
                  borderRadius: "var(--radius-input)",
                  border: `1px solid ${error ? "#c0392b" : "var(--color-border)"}`,
                  backgroundColor: "white",
                  fontSize: "15px",
                  outline: "none",
                  transition: "border-color 0.2s",
                  boxSizing: "border-box",
                }}
                onFocus={(e) => (e.target.style.borderColor = "var(--color-primary)")}
                onBlur={(e) => (e.target.style.borderColor = error ? "#c0392b" : "var(--color-border)")}
              />
            </div>
            {error && <p style={{ fontSize: "12px", color: "#c0392b", marginTop: "6px" }}>{error}</p>}
          </div>

          <button
            type="submit"
            style={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "8px",
              backgroundColor: "var(--color-primary)",
              color: "white",
              border: "none",
              borderRadius: "var(--radius-button)",
              padding: "12px",
              fontSize: "15px",
              fontWeight: 600,
              cursor: "pointer",
              boxShadow: "var(--shadow-elevated)",
              transition: "all 0.2s",
            }}
            onMouseOver={(e) => (e.currentTarget.style.opacity = "0.9")}
            onMouseOut={(e) => (e.currentTarget.style.opacity = "1")}
          >
            {mode === "login" ? <><LogIn size={15} /> Log In</> : <><UserPlus size={15} /> Sign Up</>}
          </button>

          {/* Switch mode inline hint */}
          <p style={{ fontSize: "13px", color: "var(--color-text-secondary)", textAlign: "center", margin: 0 }}>
            {mode === "login" ? "No account yet? " : "Already have an account? "}
            <button
              type="button"
              onClick={() => handleModeChange(mode === "login" ? "signup" : "login")}
              style={{ background: "none", border: "none", color: "var(--color-primary)", fontWeight: 600, fontSize: "13px", cursor: "pointer", padding: 0 }}
            >
              {mode === "login" ? "Sign Up" : "Log In"}
            </button>
          </p>
        </form>

        {/* Guest divider */}
        <div style={{ width: "100%", display: "flex", alignItems: "center", gap: "12px", margin: "20px 0 4px" }}>
          <div style={{ flex: 1, height: "1px", backgroundColor: "var(--color-border)" }} />
          <span style={{ fontSize: "12px", color: "var(--color-text-secondary)", whiteSpace: "nowrap" }}>or</span>
          <div style={{ flex: 1, height: "1px", backgroundColor: "var(--color-border)" }} />
        </div>

        <button
          onClick={() => onLogin("guest", true)}
          style={{
            width: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "8px",
            backgroundColor: "transparent",
            color: "var(--color-text-secondary)",
            border: "1px solid var(--color-border)",
            borderRadius: "var(--radius-button)",
            padding: "11px",
            fontSize: "14px",
            fontWeight: 500,
            cursor: "pointer",
            transition: "all 0.2s",
          }}
          onMouseOver={(e) => { e.currentTarget.style.borderColor = "var(--color-primary)"; e.currentTarget.style.color = "var(--color-primary)"; }}
          onMouseOut={(e) => { e.currentTarget.style.borderColor = "var(--color-border)"; e.currentTarget.style.color = "var(--color-text-secondary)"; }}
        >
          <UserRound size={15} />
          Continue as Guest
        </button>
        <p style={{ fontSize: "11px", color: "var(--color-text-secondary)", textAlign: "center", marginTop: "8px", opacity: 0.75 }}>
          Guest data is not saved between sessions.
        </p>
      </Card>
    );
  }

  // ── Phase: Sign-up QR setup ────────────────────────────────────────────
  if (phase === "setup") {
    const uri = getTOTPUri(email, secret);
    return (
      <Card>
        <div style={{ width: "40px", height: "40px", borderRadius: "50%", backgroundColor: "var(--color-primary-soft)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "16px" }}>
          <ShieldCheck size={20} style={{ color: "var(--color-primary)" }} />
        </div>

        <h1 style={{ fontFamily: "var(--font-display)", fontSize: "21px", color: "var(--color-primary)", marginBottom: "6px", textAlign: "center" }}>
          Set Up Authenticator
        </h1>
        <p style={{ color: "var(--color-text-secondary)", fontSize: "13px", marginBottom: "20px", textAlign: "center", lineHeight: 1.6 }}>
          Scan this QR code with <strong>Google Authenticator</strong>, then enter the 6-digit code to finish creating your account.
        </p>

        <div style={{ padding: "16px", backgroundColor: "white", borderRadius: "12px", border: "1px solid var(--color-border)", marginBottom: "14px", boxShadow: "0 2px 8px rgba(0,0,0,0.06)" }}>
          <QRCodeSVG value={uri} size={172} level="M" />
        </div>

        <div style={{ width: "100%", marginBottom: "18px", boxSizing: "border-box" }}>
          <p style={{ fontSize: "12px", color: "var(--color-text-secondary)", marginBottom: "6px", textAlign: "center" }}>
            Can&apos;t scan? Enter this key manually:
          </p>
          <div style={{ display: "flex", alignItems: "center", gap: "8px", backgroundColor: "var(--color-bg)", border: "1px solid var(--color-border)", borderRadius: "8px", padding: "10px 12px" }}>
            <code style={{ flex: 1, fontSize: "12px", fontFamily: "var(--font-mono)", color: "var(--color-text-primary)", letterSpacing: "0.08em", wordBreak: "break-all" }}>
              {formatSecret(secret)}
            </code>
            <button onClick={handleCopySecret} style={{ background: "none", border: "none", cursor: "pointer", padding: "2px", color: "var(--color-primary)" }} title="Copy secret">
              {copied ? <CheckCheck size={15} /> : <Copy size={15} />}
            </button>
          </div>
        </div>

        <CodeInput onSubmit={handleSetupConfirm} submitLabel="Activate & Sign In" />
      </Card>
    );
  }

  // ── Phase: Log-in TOTP verify ──────────────────────────────────────────
  return (
    <Card>
      <div style={{ width: "40px", height: "40px", borderRadius: "50%", backgroundColor: "var(--color-primary-soft)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "16px" }}>
        <ShieldCheck size={20} style={{ color: "var(--color-primary)" }} />
      </div>

      <h1 style={{ fontFamily: "var(--font-display)", fontSize: "21px", color: "var(--color-primary)", marginBottom: "6px", textAlign: "center" }}>
        Two-Factor Login
      </h1>
      <p style={{ color: "var(--color-text-secondary)", fontSize: "13px", marginBottom: "4px", textAlign: "center" }}>
        Signed in as <strong style={{ color: "var(--color-text-primary)" }}>{email}</strong>
      </p>
      <p style={{ color: "var(--color-text-secondary)", fontSize: "13px", marginBottom: "20px", textAlign: "center" }}>
        Open Google Authenticator and enter the code for <strong>ItemInsight</strong>.
      </p>

      <CodeInput onSubmit={handleVerify} submitLabel="Log In" />
    </Card>
  );
}
