export interface ThemeTokens {
  "--color-bg": string;
  "--color-surface": string;
  "--color-surface-alt": string;
  "--color-primary": string;
  "--color-primary-soft": string;
  "--color-success": string;
  "--color-success-soft": string;
  "--color-warning": string;
  "--color-warning-soft": string;
  "--color-danger": string;
  "--color-danger-soft": string;
  "--color-text-primary": string;
  "--color-text-secondary": string;
  "--color-border": string;
  "--font-display": string;
  "--font-body": string;
  "--font-mono": string;
}

export interface Theme {
  id: string;
  name: string;
  concept: string;
  swatch: string; // preview bg color
  accentSwatch: string; // preview primary color
  tokens: ThemeTokens;
}

export const THEMES: Theme[] = [
  {
    id: "academic",
    name: "Academic Cream",
    concept: "Formal, printed-document feel",
    swatch: "#F2EDE3",
    accentSwatch: "#1B4332",
    tokens: {
      "--color-bg": "#F2EDE3",
      "--color-surface": "#FAF7F0",
      "--color-surface-alt": "#EDE7D9",
      "--color-primary": "#1B4332",
      "--color-primary-soft": "#C8DDD4",
      "--color-success": "#2D6A4F",
      "--color-success-soft": "#C3DDD2",
      "--color-warning": "#7A4F1D",
      "--color-warning-soft": "#F0DFC0",
      "--color-danger": "#7D2030",
      "--color-danger-soft": "#F0D0D4",
      "--color-text-primary": "#1A1810",
      "--color-text-secondary": "#5A5240",
      "--color-border": "#C8BFA8",
      "--font-display": "'Playfair Display', serif",
      "--font-body": "'Lora', serif",
      "--font-mono": "'DM Mono', monospace",
    },
  },
  {
    id: "pureWhite",
    name: "Pure White",
    concept: "Clean, distraction-free workspace",
    swatch: "#FFFFFF",
    accentSwatch: "#2563EB",
    tokens: {
      "--color-bg": "#F8FAFC",
      "--color-surface": "#FFFFFF",
      "--color-surface-alt": "#F1F5F9",
      "--color-primary": "#2563EB",
      "--color-primary-soft": "#DBEAFE",
      "--color-success": "#22C55E",
      "--color-success-soft": "#DCFCE7",
      "--color-warning": "#F59E0B",
      "--color-warning-soft": "#FEF3C7",
      "--color-danger": "#EF4444",
      "--color-danger-soft": "#FEE2E2",
      "--color-text-primary": "#111827",
      "--color-text-secondary": "#6B7280",
      "--color-border": "#E5E7EB",
      "--font-display": "'Inter', sans-serif",
      "--font-body": "'Inter', sans-serif",
      "--font-mono": "'DM Mono', monospace",
    },
  },
  {
    id: "softSage",
    name: "Soft Sage",
    concept: "Calm and relaxing, reduces fatigue",
    swatch: "#F7FAF5",
    accentSwatch: "#5B8A72",
    tokens: {
      "--color-bg": "#F7FAF5",
      "--color-surface": "#FFFFFF",
      "--color-surface-alt": "#DCE8DD",
      "--color-primary": "#5B8A72",
      "--color-primary-soft": "#DCE8DD",
      "--color-success": "#A7C957",
      "--color-success-soft": "#EAF4CC",
      "--color-warning": "#D97706",
      "--color-warning-soft": "#FEF3C7",
      "--color-danger": "#DC2626",
      "--color-danger-soft": "#FEE2E2",
      "--color-text-primary": "#2D3748",
      "--color-text-secondary": "#718096",
      "--color-border": "#C6D9C8",
      "--font-display": "'Lora', serif",
      "--font-body": "'Lora', serif",
      "--font-mono": "'DM Mono', monospace",
    },
  },
  {
    id: "midnightDark",
    name: "Midnight Dark",
    concept: "Comfortable for nighttime use",
    swatch: "#0F172A",
    accentSwatch: "#3B82F6",
    tokens: {
      "--color-bg": "#0F172A",
      "--color-surface": "#1E293B",
      "--color-surface-alt": "#334155",
      "--color-primary": "#3B82F6",
      "--color-primary-soft": "#1E3A5F",
      "--color-success": "#22C55E",
      "--color-success-soft": "#14532D",
      "--color-warning": "#F59E0B",
      "--color-warning-soft": "#451A03",
      "--color-danger": "#F87171",
      "--color-danger-soft": "#450A0A",
      "--color-text-primary": "#F8FAFC",
      "--color-text-secondary": "#94A3B8",
      "--color-border": "#334155",
      "--font-display": "'Inter', sans-serif",
      "--font-body": "'Inter', sans-serif",
      "--font-mono": "'DM Mono', monospace",
    },
  },
  {
    id: "sandstone",
    name: "Sandstone",
    concept: "Warm and paper-inspired",
    swatch: "#F8F5F0",
    accentSwatch: "#C97B63",
    tokens: {
      "--color-bg": "#F8F5F0",
      "--color-surface": "#FFFDF9",
      "--color-surface-alt": "#E9DFC8",
      "--color-primary": "#C97B63",
      "--color-primary-soft": "#F3D5CC",
      "--color-success": "#6B705C",
      "--color-success-soft": "#D8DDCE",
      "--color-warning": "#B45309",
      "--color-warning-soft": "#FEF3C7",
      "--color-danger": "#9B2335",
      "--color-danger-soft": "#FCE4E8",
      "--color-text-primary": "#3C3C3C",
      "--color-text-secondary": "#7A7367",
      "--color-border": "#D6C9B4",
      "--font-display": "'Playfair Display', serif",
      "--font-body": "'Lora', serif",
      "--font-mono": "'DM Mono', monospace",
    },
  },
  {
    id: "oceanBlue",
    name: "Ocean Blue",
    concept: "Professional and trustworthy",
    swatch: "#F5FAFF",
    accentSwatch: "#2563EB",
    tokens: {
      "--color-bg": "#F5FAFF",
      "--color-surface": "#FFFFFF",
      "--color-surface-alt": "#DBEAFE",
      "--color-primary": "#2563EB",
      "--color-primary-soft": "#DBEAFE",
      "--color-success": "#059669",
      "--color-success-soft": "#D1FAE5",
      "--color-warning": "#D97706",
      "--color-warning-soft": "#FEF3C7",
      "--color-danger": "#DC2626",
      "--color-danger-soft": "#FEE2E2",
      "--color-text-primary": "#1F2937",
      "--color-text-secondary": "#6B7280",
      "--color-border": "#BFDBFE",
      "--font-display": "'Inter', sans-serif",
      "--font-body": "'Inter', sans-serif",
      "--font-mono": "'DM Mono', monospace",
    },
  },
  {
    id: "lavenderFocus",
    name: "Lavender Focus",
    concept: "Soft, modern, and creative",
    swatch: "#FCFAFF",
    accentSwatch: "#8B5CF6",
    tokens: {
      "--color-bg": "#FCFAFF",
      "--color-surface": "#FFFFFF",
      "--color-surface-alt": "#EDE9FE",
      "--color-primary": "#8B5CF6",
      "--color-primary-soft": "#EDE9FE",
      "--color-success": "#10B981",
      "--color-success-soft": "#D1FAE5",
      "--color-warning": "#F59E0B",
      "--color-warning-soft": "#FEF3C7",
      "--color-danger": "#EF4444",
      "--color-danger-soft": "#FEE2E2",
      "--color-text-primary": "#312E81",
      "--color-text-secondary": "#6D6ADE",
      "--color-border": "#DDD6FE",
      "--font-display": "'Inter', sans-serif",
      "--font-body": "'Inter', sans-serif",
      "--font-mono": "'DM Mono', monospace",
    },
  },
];

export const THEME_STORAGE_KEY = "iteminsight_theme";

export function getThemeById(id: string): Theme {
  return THEMES.find((t) => t.id === id) ?? THEMES[0];
}
