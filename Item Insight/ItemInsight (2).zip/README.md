
  # ItemInsight

  This is a code bundle for ItemInsight. The original project is available at https://www.figma.com/design/ORVZBxJb0xx5JeilioWHZq/ItemInsight.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  